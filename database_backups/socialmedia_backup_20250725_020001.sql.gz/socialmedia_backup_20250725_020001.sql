--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-07-25 02:00:01 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.wordpress_tags DROP CONSTRAINT wordpress_tags_account_id_fkey;
ALTER TABLE ONLY public.wordpress_categories DROP CONSTRAINT wordpress_categories_account_id_fkey;
ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_user_id_fkey;
ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_stream_id_fkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_user_id_fkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_stream_id_fkey;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_user_id_fkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_app_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_user_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_group_id_fkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_user_id_fkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_user_id_fkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_user_id_fkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_app_key_id_fkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_app_id_fkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_fkey;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_stream_sessions_updated_at ON public.stream_sessions;
DROP TRIGGER update_stream_republishing_updated_at ON public.stream_republishing;
DROP TRIGGER update_stream_apps_updated_at ON public.stream_apps;
DROP TRIGGER update_stream_app_keys_updated_at ON public.stream_app_keys;
DROP TRIGGER update_social_accounts_updated_at ON public.social_accounts;
DROP TRIGGER update_posts_updated_at ON public.posts;
DROP TRIGGER update_live_streams_updated_at ON public.live_streams;
DROP TRIGGER update_api_credentials_updated_at ON public.api_credentials;
DROP TRIGGER update_account_groups_updated_at ON public.account_groups;
DROP INDEX public.idx_wordpress_tags_account_id;
DROP INDEX public.idx_wordpress_categories_account_id;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_stream_sessions_user_id;
DROP INDEX public.idx_stream_sessions_stream_id;
DROP INDEX public.idx_stream_sessions_status;
DROP INDEX public.idx_stream_republishing_user_id;
DROP INDEX public.idx_stream_republishing_stream_id;
DROP INDEX public.idx_stream_republishing_status;
DROP INDEX public.idx_stream_apps_user_id;
DROP INDEX public.idx_stream_apps_status;
DROP INDEX public.idx_stream_app_keys_app_id;
DROP INDEX public.idx_stream_app_keys_active;
DROP INDEX public.idx_social_accounts_user_id;
DROP INDEX public.idx_social_accounts_platform;
DROP INDEX public.idx_posts_user_id;
DROP INDEX public.idx_posts_status;
DROP INDEX public.idx_posts_scheduled_time;
DROP INDEX public.idx_live_streams_user_id;
DROP INDEX public.idx_live_streams_status;
DROP INDEX public.idx_live_streams_app_key_id;
DROP INDEX public.idx_live_streams_app_id;
DROP INDEX public.idx_account_groups_user_id;
ALTER TABLE ONLY public.wordpress_tags DROP CONSTRAINT wordpress_tags_pkey;
ALTER TABLE ONLY public.wordpress_tags DROP CONSTRAINT wordpress_tags_account_id_wp_tag_id_key;
ALTER TABLE ONLY public.wordpress_categories DROP CONSTRAINT wordpress_categories_pkey;
ALTER TABLE ONLY public.wordpress_categories DROP CONSTRAINT wordpress_categories_account_id_wp_category_id_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_pkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_pkey;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_user_id_app_name_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_rtmp_app_path_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_pkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_pkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_app_id_key_name_key;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_pkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_state_key_key;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_pkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_stream_key_key;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_pkey;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_platform_key;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_pkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_name_key;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_pkey;
ALTER TABLE public.wordpress_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wordpress_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.social_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.oauth_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.api_credentials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account_groups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.wordpress_tags_id_seq;
DROP TABLE public.wordpress_tags;
DROP SEQUENCE public.wordpress_categories_id_seq;
DROP TABLE public.wordpress_categories;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.stream_sessions;
DROP TABLE public.stream_republishing;
DROP TABLE public.stream_apps;
DROP TABLE public.stream_app_keys;
DROP SEQUENCE public.social_accounts_id_seq;
DROP TABLE public.social_accounts;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.oauth_states_id_seq;
DROP TABLE public.oauth_states;
DROP TABLE public.live_streams;
DROP SEQUENCE public.api_credentials_id_seq;
DROP TABLE public.api_credentials;
DROP SEQUENCE public.account_groups_id_seq;
DROP TABLE public.account_groups;
DROP FUNCTION public.update_updated_at_column();
DROP FUNCTION public.update_stream_apps_updated_at();
DROP FUNCTION public.update_live_streams_updated_at();
--
-- TOC entry 237 (class 1255 OID 157056)
-- Name: update_live_streams_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_live_streams_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 236 (class 1255 OID 156954)
-- Name: update_stream_apps_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_stream_apps_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 235 (class 1255 OID 156885)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 156860)
-- Name: account_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    account_ids integer[] DEFAULT '{}'::integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 156859)
-- Name: account_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3669 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_groups_id_seq OWNED BY public.account_groups.id;


--
-- TOC entry 221 (class 1259 OID 156846)
-- Name: api_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_credentials (
    id integer NOT NULL,
    platform character varying(50) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret text NOT NULL,
    additional_config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 220 (class 1259 OID 156845)
-- Name: api_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3670 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_credentials_id_seq OWNED BY public.api_credentials.id;


--
-- TOC entry 228 (class 1259 OID 156957)
-- Name: live_streams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_streams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    stream_key character varying(255) NOT NULL,
    rtmp_url character varying(255) NOT NULL,
    source_app character varying(255) DEFAULT 'live'::character varying,
    source_stream character varying(255),
    status character varying(50) DEFAULT 'inactive'::character varying,
    app_id uuid,
    app_key_id uuid,
    destinations jsonb DEFAULT '[]'::jsonb,
    quality_settings jsonb DEFAULT '{}'::jsonb,
    auto_post_enabled boolean DEFAULT false,
    auto_post_accounts text[],
    auto_post_message text,
    category character varying(100),
    tags text[],
    is_public boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    thumbnail_url text,
    CONSTRAINT live_streams_status_check CHECK (((status)::text = ANY ((ARRAY['inactive'::character varying, 'live'::character varying, 'ended'::character varying, 'error'::character varying])::text[])))
);


--
-- TOC entry 225 (class 1259 OID 156890)
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_states (
    id integer NOT NULL,
    state_key character varying(255) NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    instance_url character varying(255),
    client_id character varying(255),
    client_secret character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '01:00:00'::interval),
    extra_data text
);


--
-- TOC entry 224 (class 1259 OID 156889)
-- Name: oauth_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3671 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_states_id_seq OWNED BY public.oauth_states.id;


--
-- TOC entry 219 (class 1259 OID 156826)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    media_urls text[] DEFAULT '{}'::text[],
    platforms text[] NOT NULL,
    scheduled_time timestamp with time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    post_results jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    target_accounts jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    post_type character varying(50) DEFAULT 'text'::character varying,
    is_scheduled boolean DEFAULT false,
    published_at timestamp with time zone,
    error_message text,
    featured_image_url text,
    excerpt text,
    wp_categories jsonb DEFAULT '[]'::jsonb,
    wp_tags jsonb DEFAULT '[]'::jsonb,
    wp_post_id integer,
    wp_post_status character varying(50),
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'published'::character varying, 'failed'::character varying])::text[])))
);


--
-- TOC entry 218 (class 1259 OID 156825)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3672 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 217 (class 1259 OID 156808)
-- Name: social_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_accounts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    platform_user_id character varying(255),
    username character varying(255) NOT NULL,
    display_name character varying(255),
    avatar_url text,
    instance_url character varying(255),
    access_token text,
    refresh_token text,
    token_expires_at timestamp with time zone,
    platform_data jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    last_used timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    site_url character varying(255),
    app_password text,
    site_title character varying(255),
    api_version character varying(20) DEFAULT 'v2'::character varying,
    group_id integer
);


--
-- TOC entry 216 (class 1259 OID 156807)
-- Name: social_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3673 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_accounts_id_seq OWNED BY public.social_accounts.id;


--
-- TOC entry 227 (class 1259 OID 156931)
-- Name: stream_app_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_app_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_id uuid NOT NULL,
    key_name character varying(255) NOT NULL,
    stream_key character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    usage_count integer DEFAULT 0,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 226 (class 1259 OID 156909)
-- Name: stream_apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_apps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    description text,
    rtmp_app_path character varying(255) NOT NULL,
    default_stream_key character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_apps_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'deleted'::character varying])::text[])))
);


--
-- TOC entry 230 (class 1259 OID 157019)
-- Name: stream_republishing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_republishing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    user_id integer NOT NULL,
    destination_name character varying(255) NOT NULL,
    destination_url character varying(255) NOT NULL,
    destination_port integer DEFAULT 1935,
    destination_app character varying(255) NOT NULL,
    destination_stream character varying(255) NOT NULL,
    destination_key character varying(255),
    enabled boolean DEFAULT true,
    priority integer DEFAULT 1,
    retry_attempts integer DEFAULT 3,
    status character varying(50) DEFAULT 'inactive'::character varying,
    last_error text,
    last_connected_at timestamp with time zone,
    connection_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_republishing_status_check CHECK (((status)::text = ANY ((ARRAY['inactive'::character varying, 'active'::character varying, 'error'::character varying, 'disabled'::character varying])::text[])))
);


--
-- TOC entry 229 (class 1259 OID 156991)
-- Name: stream_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    user_id integer NOT NULL,
    session_key character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    duration_seconds integer,
    peak_viewers integer DEFAULT 0,
    viewer_count integer DEFAULT 0,
    bytes_sent bigint DEFAULT 0,
    bytes_received bigint DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'ended'::character varying, 'error'::character varying])::text[])))
);


--
-- TOC entry 215 (class 1259 OID 156793)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 214 (class 1259 OID 156792)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3674 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 232 (class 1259 OID 172972)
-- Name: wordpress_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wordpress_categories (
    id integer NOT NULL,
    account_id integer NOT NULL,
    wp_category_id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 231 (class 1259 OID 172971)
-- Name: wordpress_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wordpress_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3675 (class 0 OID 0)
-- Dependencies: 231
-- Name: wordpress_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wordpress_categories_id_seq OWNED BY public.wordpress_categories.id;


--
-- TOC entry 234 (class 1259 OID 172991)
-- Name: wordpress_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wordpress_tags (
    id integer NOT NULL,
    account_id integer NOT NULL,
    wp_tag_id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 233 (class 1259 OID 172990)
-- Name: wordpress_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wordpress_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3676 (class 0 OID 0)
-- Dependencies: 233
-- Name: wordpress_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wordpress_tags_id_seq OWNED BY public.wordpress_tags.id;


--
-- TOC entry 3346 (class 2604 OID 156863)
-- Name: account_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups ALTER COLUMN id SET DEFAULT nextval('public.account_groups_id_seq'::regclass);


--
-- TOC entry 3342 (class 2604 OID 156849)
-- Name: api_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials ALTER COLUMN id SET DEFAULT nextval('public.api_credentials_id_seq'::regclass);


--
-- TOC entry 3350 (class 2604 OID 156893)
-- Name: oauth_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states ALTER COLUMN id SET DEFAULT nextval('public.oauth_states_id_seq'::regclass);


--
-- TOC entry 3331 (class 2604 OID 156829)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3323 (class 2604 OID 156811)
-- Name: social_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts ALTER COLUMN id SET DEFAULT nextval('public.social_accounts_id_seq'::regclass);


--
-- TOC entry 3318 (class 2604 OID 156796)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3391 (class 2604 OID 172975)
-- Name: wordpress_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories ALTER COLUMN id SET DEFAULT nextval('public.wordpress_categories_id_seq'::regclass);


--
-- TOC entry 3395 (class 2604 OID 172994)
-- Name: wordpress_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags ALTER COLUMN id SET DEFAULT nextval('public.wordpress_tags_id_seq'::regclass);


--
-- TOC entry 3652 (class 0 OID 156860)
-- Dependencies: 223
-- Data for Name: account_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_groups (id, user_id, name, description, account_ids, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3650 (class 0 OID 156846)
-- Dependencies: 221
-- Data for Name: api_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_credentials (id, platform, client_id, client_secret, additional_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3657 (class 0 OID 156957)
-- Dependencies: 228
-- Data for Name: live_streams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.live_streams (id, user_id, title, description, stream_key, rtmp_url, source_app, source_stream, status, app_id, app_key_id, destinations, quality_settings, auto_post_enabled, auto_post_accounts, auto_post_message, category, tags, is_public, created_at, updated_at, started_at, ended_at, thumbnail_url) FROM stdin;
c1a8b9c8-7946-4c98-88c5-4a2d4759d4b7	2	RMN		darshan	rtmp://37.27.201.26:1935/live	live	\N	inactive	ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	ed3efe4f-f61f-480c-8bb4-843466e51605	[]	{"bitrate": 4000, "framerate": 30, "resolution": "1920x1080", "audio_bitrate": 128}	f	{}	\N	\N	{}	t	2025-07-13 17:31:34.70556+00	2025-07-13 17:31:34.70556+00	\N	\N	\N
25225966-1c23-4d00-943b-97d3395676ed	2	RMN Test 2		live	rtmp://37.27.201.26:1935/socialmedia	live	\N	inactive	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	8c6bdf90-2023-48a4-a16a-172a71c56e5d	[]	{"bitrate": 4000, "framerate": 30, "resolution": "1920x1080", "audio_bitrate": 128}	f	{}	\N	\N	{}	t	2025-07-13 17:43:34.619909+00	2025-07-13 17:44:26.612543+00	\N	\N	\N
\.


--
-- TOC entry 3654 (class 0 OID 156890)
-- Dependencies: 225
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_states (id, state_key, user_id, platform, instance_url, client_id, client_secret, created_at, expires_at, extra_data) FROM stdin;
\.


--
-- TOC entry 3648 (class 0 OID 156826)
-- Dependencies: 219
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, user_id, content, media_urls, platforms, scheduled_time, status, post_results, created_at, updated_at, target_accounts, scheduled_for, post_type, is_scheduled, published_at, error_message, featured_image_url, excerpt, wp_categories, wp_tags, wp_post_id, wp_post_status) FROM stdin;
1	2	Nithyanandam	{}	{mastodon}	2025-07-05 14:00:16.996+00	published	{"results": "success"}	2025-07-05 14:00:16.405684+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:00:16.996+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
2	2	Nithyanandam	{}	{mastodon}	\N	failed	{"error": "Some accounts failed to publish"}	2025-07-05 14:09:10.943592+00	2025-07-24 21:14:00.912932+00	[]	\N	text	f	\N	\N	\N	\N	[]	[]	\N	\N
3	2	Nithyanandam	{}	{mastodon}	2025-07-05 14:11:07.53+00	published	{"results": "success"}	2025-07-05 14:11:07.100521+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:11:07.53+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
4	2	Blessings	{}	{mastodon}	\N	failed	{"error": "Some accounts failed to publish"}	2025-07-05 14:15:02.107107+00	2025-07-24 21:14:00.912932+00	[]	\N	text	f	\N	\N	\N	\N	[]	[]	\N	\N
5	2	NIthyanandam	{}	{mastodon}	2025-07-05 14:15:29.568+00	published	{"results": "success"}	2025-07-05 14:15:29.22552+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:15:29.568+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
\.


--
-- TOC entry 3646 (class 0 OID 156808)
-- Dependencies: 217
-- Data for Name: social_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_accounts (id, user_id, platform, platform_user_id, username, display_name, avatar_url, instance_url, access_token, refresh_token, token_expires_at, platform_data, is_active, created_at, updated_at, status, last_used, site_url, app_password, site_title, api_version, group_id) FROM stdin;
3	2	mastodon	\N	nithyanandayoga	KAILASA's Nithyananda Yoga	https://files.mastodon.social/accounts/avatars/114/790/722/466/991/781/original/e9748c350435b6ca.jpg	https://mastodon.social	c818f04940b1892a49d620e1a7fe8407:41b155782219b8c63f7a0d3441c34ac33830f773dcc043580855dcc8513ab291b307727bd70f7f9a4e8c67c957db5284	\N	\N	{}	t	2025-07-05 14:49:52.281569+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
4	2	mastodon	\N	SriNithyananda	KAILASA's SPH Nithyananda	https://files.mastodon.social/accounts/avatars/114/445/044/896/750/112/original/1fc187283524fb7f.jpg	https://mastodon.social	1c950a67403c75465bcaaa44442b6bad:6d19b1e79dc6f27b205681db427ce06988c65c78e6e32c2de0b650d4a34b79a0722847f430276eb209d28664a840c3e8	\N	\N	{}	t	2025-07-05 15:14:32.210196+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
5	2	mastodon	\N	SriNithyanandaTamil	KAILASA's SPH Nithyananda	https://mastodon.social/avatars/original/missing.png	https://mastodon.social	f1112e89caee91b2bac660cb4549c783:791f92884c59d4abce617420cc4a33b3ff2072c018acd26ac498ec47c582129eed21d73d1c837063fffde491e5bb1221	\N	\N	{}	t	2025-07-05 15:23:16.555754+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
6	3	x	\N	kailasanation	United States Of KAILASA	\N	\N	881941b50e76f31fd6a512052d5a5dbb:a4181ff40f505724d33266d81b796dd5105238c57f3cb78fc083a7b3800b79233b94da9d2c97b30a11ff5951acaa95acba399ee725f7b932b0aa370112fb6ef3a4866dd037a74870367c1e7012ecb097ce9e9c0a3cdf2b4f16178b0236a1df02	\N	2025-07-05 21:13:08.559+00	{}	t	2025-07-05 19:13:08.562357+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
23	2	pinterest	\N	ramanathaananda	ramanathaananda	https://i.pinimg.com/600x600_R/30/52/20/305220a1685dd84587ed52ac0de3651f.jpg	\N	7cde027983985cd0722482570fec7b83:881a081e1b88e3bf8a2c5f2a87c1d126ad1ade72e29234f263e90c273a80d9e0c3f7de0b64a3ee56deac64bd8eb5ac2150937d1aebf0af4aca70c9b3d280a2388b4c863606550242d3ddbbbaeb04b5b70f0d92100d7823612b421671eb2d6bfd1ae9c2fe13c68fc74c69b943a20b720b	\N	\N	{}	t	2025-07-07 04:11:50.935485+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
27	2	bluesky	\N	sphnithyananda.bsky.social	sphnithyananda.bsky.social	\N	\N	d155cb7ed7d10ebf0fb8946efa9cb4bd:8f669388835bfe52d1b9e5fc8fb15ffaa5743eb7d576baf737216702e18f9d11	\N	\N	{}	t	2025-07-09 20:29:13.017565+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
29	2	bluesky	\N	nithyanandayoga.bsky.social	nithyanandayoga.bsky.social	\N	\N	4c5d441a9c86f1ed3c3a56dea97d2ae0:5899829454d52b7d847e8eb936ee7e29b25c161aec26da710f672225112be210	\N	\N	{}	t	2025-07-09 20:31:37.322475+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
30	2	x	\N	NithyanandaAi	Ask Nithyananda	\N	\N	2582644e44f567a2063c04ce746b492a:be8b0b49d1a53ca9fbd55dfd5e6dbb1e35312d3e583a2225225f3f821ea45c539942af2b3c66bae25a9d2cdc8c349acfa2fa7d9bb26764b569a7cc9556aa3f6b93ccec187c9c4e20cbb88f8a33dca4c03f140bd68366e5354db2327578ae6ae0	\N	2025-07-10 14:31:17.627+00	{}	t	2025-07-10 12:31:17.627053+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
31	2	x	\N	kailasanation	United States Of KAILASA	\N	\N	052194ef2f3a0fcc8c1ea45cda82a6c2:89215843cfc0dcfd74e03074547b1473e659d20e54b23241c6ee93aab911b339dc102473017948b9284c0762782c007aacfdcf525d1e8c8db4c798c809fe57c154f1f2072dd5e081b113375300aa18904b4144100e051017b50930494254e7b9	\N	2025-07-10 14:32:10.478+00	{}	t	2025-07-10 12:32:10.47818+00	2025-07-24 21:11:21.363582+00	active	2025-07-24 21:11:30.239594+00	\N	\N	\N	v2	\N
1	2	wordpress	\N	socialmedia	Automation App	\N	\N	wordpress_app_password	\N	\N	{}	t	2025-07-24 21:39:50.641426+00	2025-07-24 21:39:50.641426+00	active	2025-07-24 21:39:50.641426+00	https://unitedancientnations.org/	8dc1f9dd4090d67f89821769dfaac6f5:2335aaa6ab1f97cdf8058738fb8e50e03a104c6070a89c7ee773473c6a1a7768	United Ancient Nations	v2	\N
2	2	wordpress	\N	socialmedia_usktan	Social Media API	\N	\N	wordpress_app_password	\N	\N	{}	t	2025-07-24 21:42:27.520921+00	2025-07-24 21:42:27.520921+00	active	2025-07-24 21:42:27.520921+00	https://usktanzania.org/	541bc1b5403a8b4fa1e9a53879045039:c5a7da1d05e3647d4a98dc95b43f3bb17323ffe8aa735138e798d20ca761be54	Sovereign Order of KAILASA Nithyananda	v2	\N
\.


--
-- TOC entry 3656 (class 0 OID 156931)
-- Dependencies: 227
-- Data for Name: stream_app_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_app_keys (id, app_id, key_name, stream_key, description, is_active, usage_count, last_used_at, created_at, updated_at) FROM stdin;
ed3efe4f-f61f-480c-8bb4-843466e51605	ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	YouTube	5b4w-rb4a-mrae-ddpq-ewus	Stream key for YouTube	t	6	2025-07-13 17:31:34.691726+00	2025-07-13 16:30:28.079562+00	2025-07-13 17:31:34.691726+00
834fde4f-12db-45d3-ace2-c428d31194c8	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	primary	live	Primary stream key	t	0	\N	2025-07-13 17:42:20.057337+00	2025-07-13 17:42:20.057337+00
8c6bdf90-2023-48a4-a16a-172a71c56e5d	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	YouTube	5b4w-rb4a-mrae-ddpq-ewus	Stream key for YouTube	t	1	2025-07-13 17:43:34.614186+00	2025-07-13 17:43:12.817868+00	2025-07-13 17:43:34.614186+00
\.


--
-- TOC entry 3655 (class 0 OID 156909)
-- Dependencies: 226
-- Data for Name: stream_apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_apps (id, user_id, app_name, description, rtmp_app_path, default_stream_key, status, settings, created_at, updated_at) FROM stdin;
ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	2	Social Media Public Stream		live	darshan	active	{}	2025-07-13 15:20:10.081986+00	2025-07-13 16:51:59.547488+00
d4832d1c-582c-42cd-b7d6-5ddcc00efffd	2	socialmedia		socialmedia	live	active	{}	2025-07-13 17:42:20.054991+00	2025-07-13 17:42:20.054991+00
\.


--
-- TOC entry 3659 (class 0 OID 157019)
-- Dependencies: 230
-- Data for Name: stream_republishing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_republishing (id, stream_id, user_id, destination_name, destination_url, destination_port, destination_app, destination_stream, destination_key, enabled, priority, retry_attempts, status, last_error, last_connected_at, connection_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3658 (class 0 OID 156991)
-- Dependencies: 229
-- Data for Name: stream_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_sessions (id, stream_id, user_id, session_key, status, started_at, ended_at, duration_seconds, peak_viewers, viewer_count, bytes_sent, bytes_received, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3644 (class 0 OID 156793)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, status, created_at, updated_at) FROM stdin;
1	test@example.com	$2a$12$R7VVNYPCBuNP0gMbdmJeburTt6qk6fcp960Zbg6K0bFVldaYfuJJC	admin	approved	2025-07-04 21:15:58.927269+00	2025-07-05 20:13:14.695999+00
3	sri.ramanatha@kailasaafrica.org	$2a$12$CTo.UdntlIQ7pPCsByu55ehB4PH9NunW3P78OgRakTy7Rbeyxau7.	user	approved	2025-07-05 16:15:27.751028+00	2025-07-11 03:04:05.076738+00
4	sri.ramanatha@nithyanandauniversity.org	$2a$12$.TODVfgk8hEWTEfma1nTtOD8idMWhgJlwg2wzSOV7qVGCx4WpXeZO	user	approved	2025-07-05 20:03:44.317584+00	2025-07-05 23:07:28.234753+00
5	newtest@test.com	$2a$12$VGsHDF.vfnDb7Odko5Q9IO92UAtNXin46TqMEQLY1mbH8fbHiaPM6	user	approved	2025-07-06 15:47:32.749578+00	2025-07-06 15:52:34.345237+00
6	sri.shivathama@uskfoundation.or.ke	$2a$12$hW31meZ7BfJfwPPqXtOEDu8ge/TM8HYcaC5fJpdZS1Oq/lhi8mwtS	user	approved	2025-07-14 13:45:18.054306+00	2025-07-14 13:45:45.905546+00
2	sri.ramanatha@uskfoundation.or.ke	$2a$12$1zmnXyj6H7a5.VywW4mCmOr0E3poknIvSTDMYyVPGGBg/VQJvbWEC	admin	approved	2025-07-04 21:18:49.347182+00	2025-07-24 20:50:32.689557+00
\.


--
-- TOC entry 3661 (class 0 OID 172972)
-- Dependencies: 232
-- Data for Name: wordpress_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wordpress_categories (id, account_id, wp_category_id, name, slug, description, created_at, updated_at) FROM stdin;
1	1	4	Diplomatic Mission	diplomatic-mission	Diplomatic Mission	2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
2	1	22	Featured News	featured		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
3	1	9	Ghana	ghana		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
4	1	5	Humanitarian Services	humanitarian-services	Humanitarian Services	2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
5	1	15	Kenya	kenya		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
6	1	10	Liberia	liberia		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
7	1	21	Mauritius	mauritius		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
8	1	20	Paraguay	paraguay		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
9	1	8	Sierra Leone	sierra-leone		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
10	1	12	South Africa	south-africa		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
11	1	16	Tanzania	tanzania		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
12	1	11	Uganda	uganda		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
13	1	64	Uncategorized	uncategorized-en		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
14	1	1	Uncategorized	uncategorized		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
15	1	14	Zambia	zambia		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
16	1	13	Zimbabwe	zimbabwe		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
17	2	4	Diplomatic Mission	diplomatic-mission	Diplomatic Mission	2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
18	2	22	Featured News	featured		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
19	2	9	Ghana	ghana		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
20	2	5	Humanitarian Services	humanitarian-services	Humanitarian Services	2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
21	2	15	Kenya	kenya		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
22	2	10	Liberia	liberia		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
23	2	21	Mauritius	mauritius		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
24	2	20	Paraguay	paraguay		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
25	2	8	Sierra Leone	sierra-leone		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
26	2	12	South Africa	south-africa		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
27	2	16	Tanzania	tanzania		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
28	2	11	Uganda	uganda		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
29	2	1	Uncategorized	uncategorized		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
30	2	14	Zambia	zambia		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
31	2	13	Zimbabwe	zimbabwe		2025-07-24 21:42:27.712312+00	2025-07-24 21:42:27.712312+00
\.


--
-- TOC entry 3663 (class 0 OID 172991)
-- Dependencies: 234
-- Data for Name: wordpress_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wordpress_tags (id, account_id, wp_tag_id, name, slug, description, created_at, updated_at) FROM stdin;
1	1	28	africa	africa		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
2	1	27	food donations	food-donations		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
3	1	23	Kailasa	kailasa		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
4	1	29	NGO	ngo		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
5	1	24	Nithyananda	nithyananda		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
6	1	26	Service	service		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
7	1	25	servicwe	servicwe		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
8	2	28	africa	africa		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
9	2	27	food donations	food-donations		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
10	2	23	Kailasa	kailasa		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
11	2	29	NGO	ngo		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
12	2	24	Nithyananda	nithyananda		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
13	2	26	Service	service		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
14	2	25	servicwe	servicwe		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
\.


--
-- TOC entry 3677 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_groups_id_seq', 2, false);


--
-- TOC entry 3678 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_credentials_id_seq', 5, false);


--
-- TOC entry 3679 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_states_id_seq', 1, false);


--
-- TOC entry 3680 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 7, true);


--
-- TOC entry 3681 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_accounts_id_seq', 2, true);


--
-- TOC entry 3682 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 7, false);


--
-- TOC entry 3683 (class 0 OID 0)
-- Dependencies: 231
-- Name: wordpress_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wordpress_categories_id_seq', 31, true);


--
-- TOC entry 3684 (class 0 OID 0)
-- Dependencies: 233
-- Name: wordpress_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wordpress_tags_id_seq', 14, true);


--
-- TOC entry 3425 (class 2606 OID 156870)
-- Name: account_groups account_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3427 (class 2606 OID 156872)
-- Name: account_groups account_groups_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_name_key UNIQUE (user_id, name);


--
-- TOC entry 3421 (class 2606 OID 156856)
-- Name: api_credentials api_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 3423 (class 2606 OID 156858)
-- Name: api_credentials api_credentials_platform_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_platform_key UNIQUE (platform);


--
-- TOC entry 3452 (class 2606 OID 156973)
-- Name: live_streams live_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3454 (class 2606 OID 156975)
-- Name: live_streams live_streams_stream_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_stream_key_key UNIQUE (stream_key);


--
-- TOC entry 3430 (class 2606 OID 156899)
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3432 (class 2606 OID 156901)
-- Name: oauth_states oauth_states_state_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_key_key UNIQUE (state_key);


--
-- TOC entry 3419 (class 2606 OID 156839)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3414 (class 2606 OID 156819)
-- Name: social_accounts social_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3444 (class 2606 OID 156944)
-- Name: stream_app_keys stream_app_keys_app_id_key_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_app_id_key_name_key UNIQUE (app_id, key_name);


--
-- TOC entry 3446 (class 2606 OID 156942)
-- Name: stream_app_keys stream_app_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3436 (class 2606 OID 156921)
-- Name: stream_apps stream_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_pkey PRIMARY KEY (id);


--
-- TOC entry 3438 (class 2606 OID 156923)
-- Name: stream_apps stream_apps_rtmp_app_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_rtmp_app_path_key UNIQUE (rtmp_app_path);


--
-- TOC entry 3440 (class 2606 OID 156925)
-- Name: stream_apps stream_apps_user_id_app_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_user_id_app_name_key UNIQUE (user_id, app_name);


--
-- TOC entry 3464 (class 2606 OID 157035)
-- Name: stream_republishing stream_republishing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_pkey PRIMARY KEY (id);


--
-- TOC entry 3459 (class 2606 OID 157008)
-- Name: stream_sessions stream_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3408 (class 2606 OID 156806)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3410 (class 2606 OID 156804)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3467 (class 2606 OID 172984)
-- Name: wordpress_categories wordpress_categories_account_id_wp_category_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories
    ADD CONSTRAINT wordpress_categories_account_id_wp_category_id_key UNIQUE (account_id, wp_category_id);


--
-- TOC entry 3469 (class 2606 OID 172982)
-- Name: wordpress_categories wordpress_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories
    ADD CONSTRAINT wordpress_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3472 (class 2606 OID 173003)
-- Name: wordpress_tags wordpress_tags_account_id_wp_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags
    ADD CONSTRAINT wordpress_tags_account_id_wp_tag_id_key UNIQUE (account_id, wp_tag_id);


--
-- TOC entry 3474 (class 2606 OID 173001)
-- Name: wordpress_tags wordpress_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags
    ADD CONSTRAINT wordpress_tags_pkey PRIMARY KEY (id);


--
-- TOC entry 3428 (class 1259 OID 156884)
-- Name: idx_account_groups_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_groups_user_id ON public.account_groups USING btree (user_id);


--
-- TOC entry 3447 (class 1259 OID 157048)
-- Name: idx_live_streams_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_app_id ON public.live_streams USING btree (app_id);


--
-- TOC entry 3448 (class 1259 OID 157049)
-- Name: idx_live_streams_app_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_app_key_id ON public.live_streams USING btree (app_key_id);


--
-- TOC entry 3449 (class 1259 OID 157047)
-- Name: idx_live_streams_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_status ON public.live_streams USING btree (status);


--
-- TOC entry 3450 (class 1259 OID 157046)
-- Name: idx_live_streams_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_user_id ON public.live_streams USING btree (user_id);


--
-- TOC entry 3415 (class 1259 OID 156883)
-- Name: idx_posts_scheduled_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_scheduled_time ON public.posts USING btree (scheduled_time);


--
-- TOC entry 3416 (class 1259 OID 156882)
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- TOC entry 3417 (class 1259 OID 156881)
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- TOC entry 3411 (class 1259 OID 156880)
-- Name: idx_social_accounts_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_platform ON public.social_accounts USING btree (platform);


--
-- TOC entry 3412 (class 1259 OID 156879)
-- Name: idx_social_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_user_id ON public.social_accounts USING btree (user_id);


--
-- TOC entry 3441 (class 1259 OID 156953)
-- Name: idx_stream_app_keys_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_app_keys_active ON public.stream_app_keys USING btree (is_active);


--
-- TOC entry 3442 (class 1259 OID 156952)
-- Name: idx_stream_app_keys_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_app_keys_app_id ON public.stream_app_keys USING btree (app_id);


--
-- TOC entry 3433 (class 1259 OID 156951)
-- Name: idx_stream_apps_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_apps_status ON public.stream_apps USING btree (status);


--
-- TOC entry 3434 (class 1259 OID 156950)
-- Name: idx_stream_apps_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_apps_user_id ON public.stream_apps USING btree (user_id);


--
-- TOC entry 3460 (class 1259 OID 157055)
-- Name: idx_stream_republishing_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_status ON public.stream_republishing USING btree (status);


--
-- TOC entry 3461 (class 1259 OID 157053)
-- Name: idx_stream_republishing_stream_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_stream_id ON public.stream_republishing USING btree (stream_id);


--
-- TOC entry 3462 (class 1259 OID 157054)
-- Name: idx_stream_republishing_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_user_id ON public.stream_republishing USING btree (user_id);


--
-- TOC entry 3455 (class 1259 OID 157052)
-- Name: idx_stream_sessions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_status ON public.stream_sessions USING btree (status);


--
-- TOC entry 3456 (class 1259 OID 157050)
-- Name: idx_stream_sessions_stream_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_stream_id ON public.stream_sessions USING btree (stream_id);


--
-- TOC entry 3457 (class 1259 OID 157051)
-- Name: idx_stream_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_user_id ON public.stream_sessions USING btree (user_id);


--
-- TOC entry 3406 (class 1259 OID 156878)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3465 (class 1259 OID 173009)
-- Name: idx_wordpress_categories_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wordpress_categories_account_id ON public.wordpress_categories USING btree (account_id);


--
-- TOC entry 3470 (class 1259 OID 173010)
-- Name: idx_wordpress_tags_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wordpress_tags_account_id ON public.wordpress_tags USING btree (account_id);


--
-- TOC entry 3495 (class 2620 OID 156908)
-- Name: account_groups update_account_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_account_groups_updated_at BEFORE UPDATE ON public.account_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3494 (class 2620 OID 156907)
-- Name: api_credentials update_api_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_credentials_updated_at BEFORE UPDATE ON public.api_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3498 (class 2620 OID 157057)
-- Name: live_streams update_live_streams_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_live_streams_updated_at BEFORE UPDATE ON public.live_streams FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3493 (class 2620 OID 156888)
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3492 (class 2620 OID 156887)
-- Name: social_accounts update_social_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_social_accounts_updated_at BEFORE UPDATE ON public.social_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3497 (class 2620 OID 156956)
-- Name: stream_app_keys update_stream_app_keys_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_app_keys_updated_at BEFORE UPDATE ON public.stream_app_keys FOR EACH ROW EXECUTE FUNCTION public.update_stream_apps_updated_at();


--
-- TOC entry 3496 (class 2620 OID 156955)
-- Name: stream_apps update_stream_apps_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_apps_updated_at BEFORE UPDATE ON public.stream_apps FOR EACH ROW EXECUTE FUNCTION public.update_stream_apps_updated_at();


--
-- TOC entry 3500 (class 2620 OID 157059)
-- Name: stream_republishing update_stream_republishing_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_republishing_updated_at BEFORE UPDATE ON public.stream_republishing FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3499 (class 2620 OID 157058)
-- Name: stream_sessions update_stream_sessions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_sessions_updated_at BEFORE UPDATE ON public.stream_sessions FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3491 (class 2620 OID 156886)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3478 (class 2606 OID 156873)
-- Name: account_groups account_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3482 (class 2606 OID 156981)
-- Name: live_streams live_streams_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.stream_apps(id) ON DELETE SET NULL;


--
-- TOC entry 3483 (class 2606 OID 156986)
-- Name: live_streams live_streams_app_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_app_key_id_fkey FOREIGN KEY (app_key_id) REFERENCES public.stream_app_keys(id) ON DELETE SET NULL;


--
-- TOC entry 3484 (class 2606 OID 156976)
-- Name: live_streams live_streams_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3479 (class 2606 OID 156902)
-- Name: oauth_states oauth_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3477 (class 2606 OID 156840)
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3475 (class 2606 OID 181164)
-- Name: social_accounts social_accounts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.account_groups(id) ON DELETE SET NULL;


--
-- TOC entry 3476 (class 2606 OID 156820)
-- Name: social_accounts social_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3481 (class 2606 OID 156945)
-- Name: stream_app_keys stream_app_keys_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.stream_apps(id) ON DELETE CASCADE;


--
-- TOC entry 3480 (class 2606 OID 156926)
-- Name: stream_apps stream_apps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3487 (class 2606 OID 157036)
-- Name: stream_republishing stream_republishing_stream_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_stream_id_fkey FOREIGN KEY (stream_id) REFERENCES public.live_streams(id) ON DELETE CASCADE;


--
-- TOC entry 3488 (class 2606 OID 157041)
-- Name: stream_republishing stream_republishing_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3485 (class 2606 OID 157009)
-- Name: stream_sessions stream_sessions_stream_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_stream_id_fkey FOREIGN KEY (stream_id) REFERENCES public.live_streams(id) ON DELETE CASCADE;


--
-- TOC entry 3486 (class 2606 OID 157014)
-- Name: stream_sessions stream_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3489 (class 2606 OID 172985)
-- Name: wordpress_categories wordpress_categories_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories
    ADD CONSTRAINT wordpress_categories_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.social_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 3490 (class 2606 OID 173004)
-- Name: wordpress_tags wordpress_tags_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags
    ADD CONSTRAINT wordpress_tags_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.social_accounts(id) ON DELETE CASCADE;


-- Completed on 2025-07-25 02:00:02 UTC

--
-- PostgreSQL database dump complete
--

