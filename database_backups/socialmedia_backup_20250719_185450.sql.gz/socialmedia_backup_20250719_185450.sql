--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-07-19 18:54:50 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_user_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_group_id_fkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_user_id_fkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_user_id_fkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_fkey;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_social_accounts_updated_at ON public.social_accounts;
DROP TRIGGER update_posts_updated_at ON public.posts;
DROP TRIGGER update_api_credentials_updated_at ON public.api_credentials;
DROP TRIGGER update_account_groups_updated_at ON public.account_groups;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_social_accounts_user_id;
DROP INDEX public.idx_social_accounts_platform;
DROP INDEX public.idx_posts_user_id;
DROP INDEX public.idx_posts_status;
DROP INDEX public.idx_posts_scheduled_time;
DROP INDEX public.idx_account_groups_user_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_pkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_pkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_state_key_key;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_pkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_pkey;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_platform_key;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_pkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_name_key;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.social_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.oauth_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.api_credentials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account_groups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.stream_apps;
DROP SEQUENCE public.social_accounts_id_seq;
DROP TABLE public.social_accounts;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.oauth_states_id_seq;
DROP TABLE public.oauth_states;
DROP TABLE public.live_streams;
DROP SEQUENCE public.api_credentials_id_seq;
DROP TABLE public.api_credentials;
DROP SEQUENCE public.account_groups_id_seq;
DROP TABLE public.account_groups;
DROP FUNCTION public.update_updated_at_column();
--
-- TOC entry 228 (class 1255 OID 42182)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 42157)
-- Name: account_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    account_ids integer[] DEFAULT '{}'::integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 42156)
-- Name: account_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_groups_id_seq OWNED BY public.account_groups.id;


--
-- TOC entry 221 (class 1259 OID 42143)
-- Name: api_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_credentials (
    id integer NOT NULL,
    platform character varying(50) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret text NOT NULL,
    additional_config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 220 (class 1259 OID 42142)
-- Name: api_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_credentials_id_seq OWNED BY public.api_credentials.id;


--
-- TOC entry 227 (class 1259 OID 42226)
-- Name: live_streams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_streams (
    id text NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    stream_key character varying(255) NOT NULL,
    rtmp_url character varying(500) NOT NULL,
    status character varying(20) DEFAULT 'inactive'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 225 (class 1259 OID 42187)
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_states (
    id integer NOT NULL,
    state_key character varying(255) NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    instance_url character varying(255),
    client_id character varying(255),
    client_secret character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '01:00:00'::interval),
    extra_data text
);


--
-- TOC entry 224 (class 1259 OID 42186)
-- Name: oauth_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_states_id_seq OWNED BY public.oauth_states.id;


--
-- TOC entry 219 (class 1259 OID 42123)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    media_urls text[] DEFAULT '{}'::text[],
    platforms text[] NOT NULL,
    scheduled_time timestamp with time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    post_results jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    post_type character varying(20) DEFAULT 'text'::character varying,
    is_scheduled boolean DEFAULT false,
    CONSTRAINT posts_post_type_check CHECK (((post_type)::text = ANY ((ARRAY['text'::character varying, 'image'::character varying, 'video'::character varying, 'reel'::character varying])::text[]))),
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'published'::character varying, 'failed'::character varying])::text[])))
);


--
-- TOC entry 218 (class 1259 OID 42122)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 217 (class 1259 OID 42105)
-- Name: social_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_accounts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    platform_user_id character varying(255),
    username character varying(255) NOT NULL,
    display_name character varying(255),
    avatar_url text,
    instance_url character varying(255),
    access_token text,
    refresh_token text,
    token_expires_at timestamp with time zone,
    platform_data jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    status character varying(20) DEFAULT 'active'::character varying,
    last_used timestamp with time zone
);


--
-- TOC entry 216 (class 1259 OID 42104)
-- Name: social_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_accounts_id_seq OWNED BY public.social_accounts.id;


--
-- TOC entry 226 (class 1259 OID 42217)
-- Name: stream_apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_apps (
    id text NOT NULL,
    user_id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    rtmp_app_path character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 215 (class 1259 OID 42090)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 214 (class 1259 OID 42089)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3317 (class 2604 OID 42160)
-- Name: account_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups ALTER COLUMN id SET DEFAULT nextval('public.account_groups_id_seq'::regclass);


--
-- TOC entry 3313 (class 2604 OID 42146)
-- Name: api_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials ALTER COLUMN id SET DEFAULT nextval('public.api_credentials_id_seq'::regclass);


--
-- TOC entry 3321 (class 2604 OID 42190)
-- Name: oauth_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states ALTER COLUMN id SET DEFAULT nextval('public.oauth_states_id_seq'::regclass);


--
-- TOC entry 3305 (class 2604 OID 42126)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3299 (class 2604 OID 42108)
-- Name: social_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts ALTER COLUMN id SET DEFAULT nextval('public.social_accounts_id_seq'::regclass);


--
-- TOC entry 3294 (class 2604 OID 42093)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3524 (class 0 OID 42157)
-- Dependencies: 223
-- Data for Name: account_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_groups (id, user_id, name, description, account_ids, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3522 (class 0 OID 42143)
-- Dependencies: 221
-- Data for Name: api_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_credentials (id, platform, client_id, client_secret, additional_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3528 (class 0 OID 42226)
-- Dependencies: 227
-- Data for Name: live_streams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.live_streams (id, user_id, title, stream_key, rtmp_url, status, created_at) FROM stdin;
c1a8b9c8-7946-4c98-88c5-4a2d4759d4b7	2	RMN	darshan	rtmp://37.27.201.26:1935/live	inactive	2025-07-19 18:50:23.016538+00
25225966-1c23-4d00-943b-97d3395676ed	2	RMN Test 2	live	rtmp://37.27.201.26:1935/socialmedia	inactive	2025-07-19 18:50:24.293771+00
\.


--
-- TOC entry 3526 (class 0 OID 42187)
-- Dependencies: 225
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_states (id, state_key, user_id, platform, instance_url, client_id, client_secret, created_at, expires_at, extra_data) FROM stdin;
\.


--
-- TOC entry 3520 (class 0 OID 42123)
-- Dependencies: 219
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, user_id, content, media_urls, platforms, scheduled_time, status, post_results, created_at, updated_at, post_type, is_scheduled) FROM stdin;
2	2	Nithyanandam	{}	{mastodon}	\N	published	{}	2025-07-19 18:37:29.814267+00	2025-07-19 18:37:29.814267+00	text	f
3	2	Nithyanandam	{}	{mastodon}	\N	failed	{}	2025-07-19 18:37:29.814267+00	2025-07-19 18:37:29.814267+00	text	f
4	2	Blessings	{}	{mastodon}	\N	failed	{}	2025-07-19 18:37:29.814267+00	2025-07-19 18:37:29.814267+00	text	f
5	2	NIthyanandam	{}	{mastodon}	\N	published	{}	2025-07-19 18:37:29.814267+00	2025-07-19 18:37:29.814267+00	text	f
\.


--
-- TOC entry 3518 (class 0 OID 42105)
-- Dependencies: 217
-- Data for Name: social_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_accounts (id, user_id, platform, platform_user_id, username, display_name, avatar_url, instance_url, access_token, refresh_token, token_expires_at, platform_data, is_active, created_at, updated_at, group_id, status, last_used) FROM stdin;
6	2	mastodon	\N	SriNithyanandaTamil	KAILASA's SPH Nithyananda	\N	\N	\N	\N	\N	{}	t	2025-07-19 18:45:28.847203+00	2025-07-19 18:45:28.847203+00	\N	active	\N
7	2	mastodon	\N	nithyanandayoga	KAILASA's Nithyananda Yoga	\N	https://mastodon.social	\N	\N	\N	{}	t	2025-07-19 18:45:41.375979+00	2025-07-19 18:45:41.375979+00	\N	active	\N
8	2	mastodon	\N	SriNithyananda	KAILASA's SPH Nithyananda	\N	https://mastodon.social	\N	\N	\N	{}	t	2025-07-19 18:45:41.375979+00	2025-07-19 18:45:41.375979+00	\N	active	\N
9	3	x	\N	kailasanation	United States Of KAILASA	\N	\N	\N	\N	\N	{}	t	2025-07-19 18:45:41.375979+00	2025-07-19 18:45:41.375979+00	\N	active	\N
10	2	pinterest	\N	ramanathaananda	ramanathaananda	\N	\N	\N	\N	\N	{}	t	2025-07-19 18:45:41.375979+00	2025-07-19 18:45:41.375979+00	\N	active	\N
\.


--
-- TOC entry 3527 (class 0 OID 42217)
-- Dependencies: 226
-- Data for Name: stream_apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_apps (id, user_id, app_name, rtmp_app_path, status, created_at) FROM stdin;
ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	2	Social Media Public Stream	live	active	2025-07-19 18:50:20.767622+00
d4832d1c-582c-42cd-b7d6-5ddcc00efffd	2	socialmedia	socialmedia	active	2025-07-19 18:50:21.959011+00
\.


--
-- TOC entry 3516 (class 0 OID 42090)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, status, created_at, updated_at) FROM stdin;
1	test@example.com	a2	admin	approved	2025-07-19 18:35:46.1527+00	2025-07-19 18:35:46.1527+00
2	sri.ramanatha@uskfoundation.or.ke	$2a$12$3x.o6wmYteklUVy83JOi/uosSSjc/G6s0rB2mD2YPdmSTxSKws336	admin	approved	2025-07-19 18:36:58.788709+00	2025-07-19 18:36:58.788709+00
4	sri.ramanatha@nithyanandauniversity.org	$2a$12$.TODVfgk8hEWTEfma1nTtOD8idMWhgJlwg2wzSOV7qVGCx4WpXeZO	user	approved	2025-07-19 18:37:01.042663+00	2025-07-19 18:37:01.042663+00
5	newtest@test.com	$2a$12$VGsHDF.vfnDb7Odko5Q9IO92UAtNXin46TqMEQLY1mbH8fbHiaPM6	user	approved	2025-07-19 18:37:02.149161+00	2025-07-19 18:37:02.149161+00
3	sri.ramanatha@kailasaafrica.org	$2a$12$CTo.UdntlIQ7pPCsByu55ehB4PH9NunW3P78OgRakTy7Rbeyxau7.	admin	approved	2025-07-19 18:36:59.835896+00	2025-07-19 18:42:12.709624+00
\.


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_groups_id_seq', 1, false);


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_credentials_id_seq', 1, false);


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_states_id_seq', 1, false);


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 5, true);


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_accounts_id_seq', 10, true);


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- TOC entry 3351 (class 2606 OID 42167)
-- Name: account_groups account_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3353 (class 2606 OID 42169)
-- Name: account_groups account_groups_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_name_key UNIQUE (user_id, name);


--
-- TOC entry 3347 (class 2606 OID 42153)
-- Name: api_credentials api_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 3349 (class 2606 OID 42155)
-- Name: api_credentials api_credentials_platform_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_platform_key UNIQUE (platform);


--
-- TOC entry 3362 (class 2606 OID 42234)
-- Name: live_streams live_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3356 (class 2606 OID 42196)
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3358 (class 2606 OID 42198)
-- Name: oauth_states oauth_states_state_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_key_key UNIQUE (state_key);


--
-- TOC entry 3345 (class 2606 OID 42136)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3340 (class 2606 OID 42116)
-- Name: social_accounts social_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3360 (class 2606 OID 42225)
-- Name: stream_apps stream_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_pkey PRIMARY KEY (id);


--
-- TOC entry 3334 (class 2606 OID 42103)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3336 (class 2606 OID 42101)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3354 (class 1259 OID 42181)
-- Name: idx_account_groups_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_groups_user_id ON public.account_groups USING btree (user_id);


--
-- TOC entry 3341 (class 1259 OID 42180)
-- Name: idx_posts_scheduled_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_scheduled_time ON public.posts USING btree (scheduled_time);


--
-- TOC entry 3342 (class 1259 OID 42179)
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- TOC entry 3343 (class 1259 OID 42178)
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- TOC entry 3337 (class 1259 OID 42177)
-- Name: idx_social_accounts_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_platform ON public.social_accounts USING btree (platform);


--
-- TOC entry 3338 (class 1259 OID 42176)
-- Name: idx_social_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_user_id ON public.social_accounts USING btree (user_id);


--
-- TOC entry 3332 (class 1259 OID 42175)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3372 (class 2620 OID 42205)
-- Name: account_groups update_account_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_account_groups_updated_at BEFORE UPDATE ON public.account_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3371 (class 2620 OID 42204)
-- Name: api_credentials update_api_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_credentials_updated_at BEFORE UPDATE ON public.api_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3370 (class 2620 OID 42185)
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3369 (class 2620 OID 42184)
-- Name: social_accounts update_social_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_social_accounts_updated_at BEFORE UPDATE ON public.social_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3368 (class 2620 OID 42183)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3366 (class 2606 OID 42170)
-- Name: account_groups account_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3367 (class 2606 OID 42199)
-- Name: oauth_states oauth_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3365 (class 2606 OID 42137)
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3363 (class 2606 OID 42207)
-- Name: social_accounts social_accounts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.account_groups(id) ON DELETE SET NULL;


--
-- TOC entry 3364 (class 2606 OID 42117)
-- Name: social_accounts social_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-07-19 18:54:50 UTC

--
-- PostgreSQL database dump complete
--

