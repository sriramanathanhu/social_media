--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-07-26 02:00:02 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_user_id_fkey;
ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_stream_id_fkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_user_id_fkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_stream_id_fkey;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_user_id_fkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_app_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_user_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_group_id_fkey;
ALTER TABLE ONLY public.reddit_subreddits DROP CONSTRAINT reddit_subreddits_account_id_fkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_user_id_fkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_user_id_fkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_user_id_fkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_fkey;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_stream_sessions_updated_at ON public.stream_sessions;
DROP TRIGGER update_stream_republishing_updated_at ON public.stream_republishing;
DROP TRIGGER update_stream_apps_updated_at ON public.stream_apps;
DROP TRIGGER update_stream_app_keys_updated_at ON public.stream_app_keys;
DROP TRIGGER update_social_accounts_updated_at ON public.social_accounts;
DROP TRIGGER update_posts_updated_at ON public.posts;
DROP TRIGGER update_live_streams_updated_at ON public.live_streams;
DROP TRIGGER update_api_credentials_updated_at ON public.api_credentials;
DROP TRIGGER update_account_groups_updated_at ON public.account_groups;
DROP INDEX public.idx_wordpress_tags_account_id;
DROP INDEX public.idx_wordpress_categories_account_id;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_stream_sessions_user_id;
DROP INDEX public.idx_stream_sessions_stream_id;
DROP INDEX public.idx_stream_sessions_status;
DROP INDEX public.idx_stream_republishing_user_id;
DROP INDEX public.idx_stream_republishing_stream_id;
DROP INDEX public.idx_stream_republishing_status;
DROP INDEX public.idx_stream_apps_user_id;
DROP INDEX public.idx_stream_apps_status;
DROP INDEX public.idx_stream_app_keys_app_id;
DROP INDEX public.idx_stream_app_keys_active;
DROP INDEX public.idx_social_accounts_user_id;
DROP INDEX public.idx_social_accounts_platform;
DROP INDEX public.idx_posts_user_id;
DROP INDEX public.idx_posts_status;
DROP INDEX public.idx_posts_scheduled_time;
DROP INDEX public.idx_live_streams_user_id;
DROP INDEX public.idx_live_streams_status;
DROP INDEX public.idx_live_streams_app_key_id;
DROP INDEX public.idx_live_streams_app_id;
DROP INDEX public.idx_account_groups_user_id;
ALTER TABLE ONLY public.wordpress_tags DROP CONSTRAINT wordpress_tags_pkey;
ALTER TABLE ONLY public.wordpress_tags DROP CONSTRAINT wordpress_tags_account_id_wp_tag_id_key;
ALTER TABLE ONLY public.wordpress_categories DROP CONSTRAINT wordpress_categories_pkey;
ALTER TABLE ONLY public.wordpress_categories DROP CONSTRAINT wordpress_categories_account_id_wp_category_id_key;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.stream_sessions DROP CONSTRAINT stream_sessions_pkey;
ALTER TABLE ONLY public.stream_republishing DROP CONSTRAINT stream_republishing_pkey;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_user_id_app_name_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_rtmp_app_path_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_pkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_pkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_app_id_key_name_key;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_pkey;
ALTER TABLE ONLY public.reddit_subreddits DROP CONSTRAINT reddit_subreddits_pkey;
ALTER TABLE ONLY public.reddit_subreddits DROP CONSTRAINT reddit_subreddits_account_id_subreddit_name_key;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_state_key_key;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_pkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_stream_key_key;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_pkey;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_platform_key;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_pkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_name_key;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_pkey;
ALTER TABLE public.wordpress_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.wordpress_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.social_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.reddit_subreddits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.oauth_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.api_credentials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account_groups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.wordpress_tags_id_seq;
DROP TABLE public.wordpress_tags;
DROP SEQUENCE public.wordpress_categories_id_seq;
DROP TABLE public.wordpress_categories;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.stream_sessions;
DROP TABLE public.stream_republishing;
DROP TABLE public.stream_apps;
DROP TABLE public.stream_app_keys;
DROP SEQUENCE public.social_accounts_id_seq;
DROP TABLE public.social_accounts;
DROP SEQUENCE public.reddit_subreddits_id_seq;
DROP TABLE public.reddit_subreddits;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.oauth_states_id_seq;
DROP TABLE public.oauth_states;
DROP TABLE public.live_streams;
DROP SEQUENCE public.api_credentials_id_seq;
DROP TABLE public.api_credentials;
DROP SEQUENCE public.account_groups_id_seq;
DROP TABLE public.account_groups;
DROP FUNCTION public.update_updated_at_column();
DROP FUNCTION public.update_stream_apps_updated_at();
DROP FUNCTION public.update_live_streams_updated_at();
--
-- TOC entry 237 (class 1255 OID 304208)
-- Name: update_live_streams_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_live_streams_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 238 (class 1255 OID 304209)
-- Name: update_stream_apps_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_stream_apps_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 239 (class 1255 OID 304210)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 218 (class 1259 OID 304211)
-- Name: account_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    account_ids integer[] DEFAULT '{}'::integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 219 (class 1259 OID 304219)
-- Name: account_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3691 (class 0 OID 0)
-- Dependencies: 219
-- Name: account_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_groups_id_seq OWNED BY public.account_groups.id;


--
-- TOC entry 220 (class 1259 OID 304220)
-- Name: api_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_credentials (
    id integer NOT NULL,
    platform character varying(50) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret text NOT NULL,
    additional_config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    created_by integer
);


--
-- TOC entry 221 (class 1259 OID 304228)
-- Name: api_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3692 (class 0 OID 0)
-- Dependencies: 221
-- Name: api_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_credentials_id_seq OWNED BY public.api_credentials.id;


--
-- TOC entry 222 (class 1259 OID 304229)
-- Name: live_streams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_streams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    stream_key character varying(255) NOT NULL,
    rtmp_url character varying(255) NOT NULL,
    source_app character varying(255) DEFAULT 'live'::character varying,
    source_stream character varying(255),
    status character varying(50) DEFAULT 'inactive'::character varying,
    app_id uuid,
    app_key_id uuid,
    destinations jsonb DEFAULT '[]'::jsonb,
    quality_settings jsonb DEFAULT '{}'::jsonb,
    auto_post_enabled boolean DEFAULT false,
    auto_post_accounts text[],
    auto_post_message text,
    category character varying(100),
    tags text[],
    is_public boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    thumbnail_url text,
    CONSTRAINT live_streams_status_check CHECK (((status)::text = ANY (ARRAY[('inactive'::character varying)::text, ('live'::character varying)::text, ('ended'::character varying)::text, ('error'::character varying)::text])))
);


--
-- TOC entry 223 (class 1259 OID 304244)
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_states (
    id integer NOT NULL,
    state_key character varying(255) NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    instance_url character varying(255),
    client_id character varying(255),
    client_secret character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '01:00:00'::interval),
    extra_data text
);


--
-- TOC entry 224 (class 1259 OID 304251)
-- Name: oauth_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3693 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_states_id_seq OWNED BY public.oauth_states.id;


--
-- TOC entry 225 (class 1259 OID 304252)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    media_urls text[] DEFAULT '{}'::text[],
    platforms text[] NOT NULL,
    scheduled_time timestamp with time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    post_results jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    target_accounts jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    post_type character varying(50) DEFAULT 'text'::character varying,
    is_scheduled boolean DEFAULT false,
    published_at timestamp with time zone,
    error_message text,
    featured_image_url text,
    excerpt text,
    wp_categories jsonb DEFAULT '[]'::jsonb,
    wp_tags jsonb DEFAULT '[]'::jsonb,
    wp_post_id integer,
    wp_post_status character varying(50),
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY (ARRAY[('draft'::character varying)::text, ('scheduled'::character varying)::text, ('published'::character varying)::text, ('failed'::character varying)::text])))
);


--
-- TOC entry 226 (class 1259 OID 304268)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3694 (class 0 OID 0)
-- Dependencies: 226
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 217 (class 1259 OID 304187)
-- Name: reddit_subreddits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reddit_subreddits (
    id integer NOT NULL,
    account_id integer,
    subreddit_name character varying(255) NOT NULL,
    display_name character varying(255),
    title character varying(255),
    description text,
    subscribers integer DEFAULT 0,
    submission_type character varying(50) DEFAULT 'any'::character varying,
    can_submit boolean DEFAULT true,
    is_moderator boolean DEFAULT false,
    over_18 boolean DEFAULT false,
    created_utc integer,
    last_synced timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    flair_enabled boolean DEFAULT false,
    flair_list jsonb DEFAULT '[]'::jsonb,
    rules jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 216 (class 1259 OID 304186)
-- Name: reddit_subreddits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reddit_subreddits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3695 (class 0 OID 0)
-- Dependencies: 216
-- Name: reddit_subreddits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reddit_subreddits_id_seq OWNED BY public.reddit_subreddits.id;


--
-- TOC entry 215 (class 1259 OID 304091)
-- Name: social_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_accounts (
    id integer NOT NULL,
    user_id integer,
    platform character varying(50) NOT NULL,
    instance_url character varying(255),
    username character varying(255) NOT NULL,
    display_name character varying(255),
    avatar_url text,
    access_token text NOT NULL,
    refresh_token text,
    token_expires_at timestamp without time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    last_used timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    group_id integer,
    site_url character varying(255),
    app_password text,
    site_title character varying(255),
    api_version character varying(10) DEFAULT 'v2'::character varying,
    reddit_karma integer DEFAULT 0,
    reddit_created_utc integer,
    reddit_is_gold boolean DEFAULT false,
    platform_user_id character varying(255),
    platform_data jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true
);


--
-- TOC entry 227 (class 1259 OID 304269)
-- Name: social_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3696 (class 0 OID 0)
-- Dependencies: 227
-- Name: social_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_accounts_id_seq OWNED BY public.social_accounts.id;


--
-- TOC entry 228 (class 1259 OID 304270)
-- Name: stream_app_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_app_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    app_id uuid NOT NULL,
    key_name character varying(255) NOT NULL,
    stream_key character varying(255) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    usage_count integer DEFAULT 0,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 229 (class 1259 OID 304280)
-- Name: stream_apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_apps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    description text,
    rtmp_app_path character varying(255) NOT NULL,
    default_stream_key character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_apps_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('inactive'::character varying)::text, ('deleted'::character varying)::text])))
);


--
-- TOC entry 230 (class 1259 OID 304291)
-- Name: stream_republishing; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_republishing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    user_id integer NOT NULL,
    destination_name character varying(255) NOT NULL,
    destination_url character varying(255) NOT NULL,
    destination_port integer DEFAULT 1935,
    destination_app character varying(255) NOT NULL,
    destination_stream character varying(255) NOT NULL,
    destination_key character varying(255),
    enabled boolean DEFAULT true,
    priority integer DEFAULT 1,
    retry_attempts integer DEFAULT 3,
    status character varying(50) DEFAULT 'inactive'::character varying,
    last_error text,
    last_connected_at timestamp with time zone,
    connection_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_republishing_status_check CHECK (((status)::text = ANY (ARRAY[('inactive'::character varying)::text, ('active'::character varying)::text, ('error'::character varying)::text, ('disabled'::character varying)::text])))
);


--
-- TOC entry 231 (class 1259 OID 304306)
-- Name: stream_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stream_id uuid NOT NULL,
    user_id integer NOT NULL,
    session_key character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    duration_seconds integer,
    peak_viewers integer DEFAULT 0,
    viewer_count integer DEFAULT 0,
    bytes_sent bigint DEFAULT 0,
    bytes_received bigint DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stream_sessions_status_check CHECK (((status)::text = ANY (ARRAY[('active'::character varying)::text, ('ended'::character varying)::text, ('error'::character varying)::text])))
);


--
-- TOC entry 214 (class 1259 OID 304074)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'user'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 232 (class 1259 OID 304322)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3697 (class 0 OID 0)
-- Dependencies: 232
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 233 (class 1259 OID 304323)
-- Name: wordpress_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wordpress_categories (
    id integer NOT NULL,
    account_id integer NOT NULL,
    wp_category_id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 234 (class 1259 OID 304331)
-- Name: wordpress_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wordpress_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3698 (class 0 OID 0)
-- Dependencies: 234
-- Name: wordpress_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wordpress_categories_id_seq OWNED BY public.wordpress_categories.id;


--
-- TOC entry 235 (class 1259 OID 304332)
-- Name: wordpress_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wordpress_tags (
    id integer NOT NULL,
    account_id integer NOT NULL,
    wp_tag_id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text DEFAULT ''::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 236 (class 1259 OID 304340)
-- Name: wordpress_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wordpress_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3699 (class 0 OID 0)
-- Dependencies: 236
-- Name: wordpress_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wordpress_tags_id_seq OWNED BY public.wordpress_tags.id;


--
-- TOC entry 3349 (class 2604 OID 304341)
-- Name: account_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups ALTER COLUMN id SET DEFAULT nextval('public.account_groups_id_seq'::regclass);


--
-- TOC entry 3353 (class 2604 OID 304342)
-- Name: api_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials ALTER COLUMN id SET DEFAULT nextval('public.api_credentials_id_seq'::regclass);


--
-- TOC entry 3367 (class 2604 OID 304343)
-- Name: oauth_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states ALTER COLUMN id SET DEFAULT nextval('public.oauth_states_id_seq'::regclass);


--
-- TOC entry 3370 (class 2604 OID 304344)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3337 (class 2604 OID 304190)
-- Name: reddit_subreddits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reddit_subreddits ALTER COLUMN id SET DEFAULT nextval('public.reddit_subreddits_id_seq'::regclass);


--
-- TOC entry 3328 (class 2604 OID 304345)
-- Name: social_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts ALTER COLUMN id SET DEFAULT nextval('public.social_accounts_id_seq'::regclass);


--
-- TOC entry 3323 (class 2604 OID 304346)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3410 (class 2604 OID 304347)
-- Name: wordpress_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories ALTER COLUMN id SET DEFAULT nextval('public.wordpress_categories_id_seq'::regclass);


--
-- TOC entry 3414 (class 2604 OID 304348)
-- Name: wordpress_tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags ALTER COLUMN id SET DEFAULT nextval('public.wordpress_tags_id_seq'::regclass);


--
-- TOC entry 3667 (class 0 OID 304211)
-- Dependencies: 218
-- Data for Name: account_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_groups (id, user_id, name, description, account_ids, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3669 (class 0 OID 304220)
-- Dependencies: 220
-- Data for Name: api_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_credentials (id, platform, client_id, client_secret, additional_config, created_at, updated_at, status, created_by) FROM stdin;
\.


--
-- TOC entry 3671 (class 0 OID 304229)
-- Dependencies: 222
-- Data for Name: live_streams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.live_streams (id, user_id, title, description, stream_key, rtmp_url, source_app, source_stream, status, app_id, app_key_id, destinations, quality_settings, auto_post_enabled, auto_post_accounts, auto_post_message, category, tags, is_public, created_at, updated_at, started_at, ended_at, thumbnail_url) FROM stdin;
c1a8b9c8-7946-4c98-88c5-4a2d4759d4b7	2	RMN		darshan	rtmp://37.27.201.26:1935/live	live	\N	inactive	ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	ed3efe4f-f61f-480c-8bb4-843466e51605	[]	{"bitrate": 4000, "framerate": 30, "resolution": "1920x1080", "audio_bitrate": 128}	f	{}	\N	\N	{}	t	2025-07-13 17:31:34.70556+00	2025-07-13 17:31:34.70556+00	\N	\N	\N
25225966-1c23-4d00-943b-97d3395676ed	2	RMN Test 2		live	rtmp://37.27.201.26:1935/socialmedia	live	\N	inactive	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	8c6bdf90-2023-48a4-a16a-172a71c56e5d	[]	{"bitrate": 4000, "framerate": 30, "resolution": "1920x1080", "audio_bitrate": 128}	f	{}	\N	\N	{}	t	2025-07-13 17:43:34.619909+00	2025-07-13 17:44:26.612543+00	\N	\N	\N
\.


--
-- TOC entry 3672 (class 0 OID 304244)
-- Dependencies: 223
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_states (id, state_key, user_id, platform, instance_url, client_id, client_secret, created_at, expires_at, extra_data) FROM stdin;
1	reddit_0ed3743ce331ef8b40f113dcd5a8209e	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:17:43.313279+00	2025-07-26 01:17:43.313279+00	{"userId":2,"random":"0ed3743ce331ef8b40f113dcd5a8209e","platform":"reddit"}
2	reddit_f5decab52bc00a308adcacdf7c3f050b	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:19:21.237415+00	2025-07-26 01:19:21.237415+00	{"userId":2,"random":"f5decab52bc00a308adcacdf7c3f050b","platform":"reddit"}
3	reddit_0f828fe583ee9886733037592492f34c	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:19:58.350954+00	2025-07-26 01:19:58.350954+00	{"userId":2,"random":"0f828fe583ee9886733037592492f34c","platform":"reddit"}
4	reddit_f6d3e691f5e6bb298e9ddbbe9b3152ea	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:20:08.95733+00	2025-07-26 01:20:08.95733+00	{"userId":2,"random":"f6d3e691f5e6bb298e9ddbbe9b3152ea","platform":"reddit"}
5	reddit_d994213c9c14882fa9936dc91d0f52c2	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:29:52.2969+00	2025-07-26 01:29:52.2969+00	{"userId":2,"random":"d994213c9c14882fa9936dc91d0f52c2","platform":"reddit"}
6	reddit_f8c34958519642ff4310eafbaa7893ba	2	reddit	\N	xym1njw3qp52EkQf4ZTUWQ	LSWQYEul_LH8IgAhFdhAEbmOAeWUMg	2025-07-26 00:33:31.789457+00	2025-07-26 01:33:31.789457+00	{"userId":2,"random":"f8c34958519642ff4310eafbaa7893ba","platform":"reddit"}
\.


--
-- TOC entry 3674 (class 0 OID 304252)
-- Dependencies: 225
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, user_id, content, media_urls, platforms, scheduled_time, status, post_results, created_at, updated_at, target_accounts, scheduled_for, post_type, is_scheduled, published_at, error_message, featured_image_url, excerpt, wp_categories, wp_tags, wp_post_id, wp_post_status) FROM stdin;
1	2	Nithyanandam	{}	{mastodon}	2025-07-05 14:00:16.996+00	published	{"results": "success"}	2025-07-05 14:00:16.405684+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:00:16.996+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
2	2	Nithyanandam	{}	{mastodon}	\N	failed	{"error": "Some accounts failed to publish"}	2025-07-05 14:09:10.943592+00	2025-07-24 21:14:00.912932+00	[]	\N	text	f	\N	\N	\N	\N	[]	[]	\N	\N
3	2	Nithyanandam	{}	{mastodon}	2025-07-05 14:11:07.53+00	published	{"results": "success"}	2025-07-05 14:11:07.100521+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:11:07.53+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
4	2	Blessings	{}	{mastodon}	\N	failed	{"error": "Some accounts failed to publish"}	2025-07-05 14:15:02.107107+00	2025-07-24 21:14:00.912932+00	[]	\N	text	f	\N	\N	\N	\N	[]	[]	\N	\N
5	2	NIthyanandam	{}	{mastodon}	2025-07-05 14:15:29.568+00	published	{"results": "success"}	2025-07-05 14:15:29.22552+00	2025-07-24 21:14:00.912932+00	[]	2025-07-05 14:15:29.568+00	text	f	\N	\N	\N	\N	[]	[]	\N	\N
\.


--
-- TOC entry 3666 (class 0 OID 304187)
-- Dependencies: 217
-- Data for Name: reddit_subreddits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reddit_subreddits (id, account_id, subreddit_name, display_name, title, description, subscribers, submission_type, can_submit, is_moderator, over_18, created_utc, last_synced, flair_enabled, flair_list, rules, created_at, updated_at) FROM stdin;
4	33	worldnews	r/worldnews	World News	A place for major news from around the world, excluding US-internal news.	46792974	link	t	f	f	1201231119	2025-07-26 00:42:32.166121	f	[]	[]	2025-07-26 00:42:32.166121	2025-07-26 00:42:32.166121
5	33	AskReddit	r/AskReddit	Ask Reddit...	r/AskReddit is the place to ask and answer thought-provoking questions.	56689840	self	t	f	f	1201233135	2025-07-26 00:42:32.168127	f	[]	[]	2025-07-26 00:42:32.168127	2025-07-26 00:42:32.168127
6	33	Damnthatsinteresting	r/Damnthatsinteresting	Damn, that's interesting!	For the most interesting things on the internet	19848518	link	t	f	f	1374425825	2025-07-26 00:42:32.169044	f	[]	[]	2025-07-26 00:42:32.169044	2025-07-26 00:42:32.169044
7	33	n8n	r/n8n	n8n: Powerfully Easy Automation	https://n8n.io/ and \n\nhttps://github.com/n8n-io/n8n\n\nn8n is an extendable workflow automation tool. With a [fair-code](http://faircode.io/) distribution model, n8n will always have visible source code, be available to self-host, and allow you to add your own custom functions, logic and apps. n8n's node-based approach makes it highly versatile, enabling you to connect anything to everything.	113196	any	t	f	f	1601401182	2025-07-26 00:42:32.171302	f	[]	[]	2025-07-26 00:42:32.171302	2025-07-26 00:42:32.171302
8	33	ClaudeAI	r/ClaudeAI	ClaudeAI	This is a Claude-information subreddit which aims to help everyone make a fully informed decision about how to use Claude to best effect for their individual purposes. ¹⌉ This subreddit is not controlled, operated or sanctioned by Anthropic. ²⌉ If your problem requires Anthropic's help, visit https://support.anthropic.com/ This subreddit is not the right place to fix your account issues. ³⌉ For more help, check the resources below. ⁴⌉ Please read the rules before posting.\n\n	283514	any	t	f	f	1674476361	2025-07-26 00:42:32.172191	f	[]	[]	2025-07-26 00:42:32.172191	2025-07-26 00:42:32.172191
9	33	AskNithyanandaAI	r/AskNithyanandaAI	AskNithyanandaAI	Welcome to r/AskNithyananda – your portal to divine AI wisdom inspired by the teachings of The SPH Nithyananda Paramashivam.\n\nThis is a space to explore, ask questions, share insights, and have fun with the AI-powered Swamiji at nithyananda.ai. Whether you're here for spiritual exploration, comic curiosity, or cosmic contemplation, all are welcome!	2	any	t	t	f	1745348964	2025-07-26 00:42:32.17533	f	[]	[]	2025-07-26 00:42:32.17533	2025-07-26 00:42:32.17533
10	33	NithyanandaBooks	r/NithyanandaBooks	NithyanandaBooks	Nithyanandam, A community to read and share the books of The SPH.	2	any	t	t	f	1745358086	2025-07-26 00:42:32.176219	f	[]	[]	2025-07-26 00:42:32.176219	2025-07-26 00:42:32.176219
\.


--
-- TOC entry 3664 (class 0 OID 304091)
-- Dependencies: 215
-- Data for Name: social_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_accounts (id, user_id, platform, instance_url, username, display_name, avatar_url, access_token, refresh_token, token_expires_at, status, last_used, created_at, updated_at, group_id, site_url, app_password, site_title, api_version, reddit_karma, reddit_created_utc, reddit_is_gold, platform_user_id, platform_data, is_active) FROM stdin;
3	2	mastodon	https://mastodon.social	nithyanandayoga	KAILASA's Nithyananda Yoga	https://files.mastodon.social/accounts/avatars/114/790/722/466/991/781/original/e9748c350435b6ca.jpg	c818f04940b1892a49d620e1a7fe8407:41b155782219b8c63f7a0d3441c34ac33830f773dcc043580855dcc8513ab291b307727bd70f7f9a4e8c67c957db5284	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-05 14:49:52.281569	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
4	2	mastodon	https://mastodon.social	SriNithyananda	KAILASA's SPH Nithyananda	https://files.mastodon.social/accounts/avatars/114/445/044/896/750/112/original/1fc187283524fb7f.jpg	1c950a67403c75465bcaaa44442b6bad:6d19b1e79dc6f27b205681db427ce06988c65c78e6e32c2de0b650d4a34b79a0722847f430276eb209d28664a840c3e8	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-05 15:14:32.210196	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
5	2	mastodon	https://mastodon.social	SriNithyanandaTamil	KAILASA's SPH Nithyananda	https://mastodon.social/avatars/original/missing.png	f1112e89caee91b2bac660cb4549c783:791f92884c59d4abce617420cc4a33b3ff2072c018acd26ac498ec47c582129eed21d73d1c837063fffde491e5bb1221	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-05 15:23:16.555754	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
6	3	x	\N	kailasanation	United States Of KAILASA	\N	881941b50e76f31fd6a512052d5a5dbb:a4181ff40f505724d33266d81b796dd5105238c57f3cb78fc083a7b3800b79233b94da9d2c97b30a11ff5951acaa95acba399ee725f7b932b0aa370112fb6ef3a4866dd037a74870367c1e7012ecb097ce9e9c0a3cdf2b4f16178b0236a1df02	\N	2025-07-05 21:13:08.559	active	2025-07-24 21:11:30.239594	2025-07-05 19:13:08.562357	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
23	2	pinterest	\N	ramanathaananda	ramanathaananda	https://i.pinimg.com/600x600_R/30/52/20/305220a1685dd84587ed52ac0de3651f.jpg	7cde027983985cd0722482570fec7b83:881a081e1b88e3bf8a2c5f2a87c1d126ad1ade72e29234f263e90c273a80d9e0c3f7de0b64a3ee56deac64bd8eb5ac2150937d1aebf0af4aca70c9b3d280a2388b4c863606550242d3ddbbbaeb04b5b70f0d92100d7823612b421671eb2d6bfd1ae9c2fe13c68fc74c69b943a20b720b	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-07 04:11:50.935485	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
27	2	bluesky	\N	sphnithyananda.bsky.social	sphnithyananda.bsky.social	\N	d155cb7ed7d10ebf0fb8946efa9cb4bd:8f669388835bfe52d1b9e5fc8fb15ffaa5743eb7d576baf737216702e18f9d11	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-09 20:29:13.017565	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
29	2	bluesky	\N	nithyanandayoga.bsky.social	nithyanandayoga.bsky.social	\N	4c5d441a9c86f1ed3c3a56dea97d2ae0:5899829454d52b7d847e8eb936ee7e29b25c161aec26da710f672225112be210	\N	\N	active	2025-07-24 21:11:30.239594	2025-07-09 20:31:37.322475	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
30	2	x	\N	NithyanandaAi	Ask Nithyananda	\N	2582644e44f567a2063c04ce746b492a:be8b0b49d1a53ca9fbd55dfd5e6dbb1e35312d3e583a2225225f3f821ea45c539942af2b3c66bae25a9d2cdc8c349acfa2fa7d9bb26764b569a7cc9556aa3f6b93ccec187c9c4e20cbb88f8a33dca4c03f140bd68366e5354db2327578ae6ae0	\N	2025-07-10 14:31:17.627	active	2025-07-24 21:11:30.239594	2025-07-10 12:31:17.627053	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
31	2	x	\N	kailasanation	United States Of KAILASA	\N	052194ef2f3a0fcc8c1ea45cda82a6c2:89215843cfc0dcfd74e03074547b1473e659d20e54b23241c6ee93aab911b339dc102473017948b9284c0762782c007aacfdcf525d1e8c8db4c798c809fe57c154f1f2072dd5e081b113375300aa18904b4144100e051017b50930494254e7b9	\N	2025-07-10 14:32:10.478	active	2025-07-24 21:11:30.239594	2025-07-10 12:32:10.47818	2025-07-24 21:11:21.363582	\N	\N	\N	\N	v2	0	\N	f	\N	{}	t
1	2	wordpress	\N	socialmedia	Automation App	\N	wordpress_app_password	\N	\N	active	2025-07-24 21:39:50.641426	2025-07-24 21:39:50.641426	2025-07-24 21:39:50.641426	\N	https://unitedancientnations.org/	8dc1f9dd4090d67f89821769dfaac6f5:2335aaa6ab1f97cdf8058738fb8e50e03a104c6070a89c7ee773473c6a1a7768	United Ancient Nations	v2	0	\N	f	\N	{}	t
2	2	wordpress	\N	socialmedia_usktan	Social Media API	\N	wordpress_app_password	\N	\N	active	2025-07-24 21:42:27.520921	2025-07-24 21:42:27.520921	2025-07-24 21:42:27.520921	\N	https://usktanzania.org/	541bc1b5403a8b4fa1e9a53879045039:c5a7da1d05e3647d4a98dc95b43f3bb17323ffe8aa735138e798d20ca761be54	Sovereign Order of KAILASA Nithyananda	v2	0	\N	f	\N	{}	t
33	2	reddit	\N	SPHNithyananda	SPHNithyananda	\N	6aa8ead3a19c7e1c3254f3682b028f31:fb9ec9336871ed6d2c267d0ae26889f6463ddc215055756b895cd2538cabece324f0c28a289816e3aed5d547bb893aad71d28c433b42caa806e98c287f0b3b078b60946c3ec3719187ede55f6f6206421bbd9ec27009523c0a179f110bf9b600f89a3798b07b08bd2897ca440525daffa8cecd0db7b2ce2151b2c6c18f64d711a3d2b8ab5cca858e5e774c9e2452085188048bf7241617a2af421e67c75d09575f22bf78493ad03108819ae12746b8c62b7ff4aa0799c2fab0f097662daa04593212be0019bdf80d28dc3f2f47b6131723c6797b2271680df3fd6395fcb9801ef069b234dd2173237fb3aea872ece4b05fc5592c1cd79dffe21a64f074f219ca3a1ac8fb16f448df6e44127e5fe4df67158cf8e32fbd4a24f0a228b77f5498e978612940c230e08b6bcf82a05f399c1139130094624e652174ef3d50543b7bebc04e8b864d652ec1ff86934ce7e6c51564c7e75366d60d5562a2282cfe903a4206b2ca76689dafc90f6a2ef6a1f70d3075a488ff0e5d267903e4d574049bc14a5010b3d1c11f32bb0e5a0b92e174d2bb36c3ac34551589c614e87188e592df108bf1deedbef62c28a98ab07a380c3a97515b35286a067e075abe19206041ecbd88657aa6c680dcb9f99f95e42bddd885bf6a9c0df5e60350f0b18bf8a534aef3ed0d3711a9ce961d564bebcb3102a9eb9da1e3ed9e5eb89a883442d92feb4064c8298e433ae768e95456d41053533af4ff290816ecde79246c80640761b09c243ef1d9f358f16eb317f0e013e48918c94e7d1346b03c1fd4023e75684fb8d24b6a43c4c6af20016f350617a04566e44e24cdc14dd17c35cadab740a383799a681660f7d3af1d68ef3cc9a6b8b526d2cb6c52aee6c59e92c678aef77100cac6d7d3f289e9410c2c914eb2a373cd5d36be7f66a650224ce6a66994391772b3f5a536566d1b66ede3b7fab87de9059b70fc56764d6933245c054ce1c83c2b4ec256dc0aa3cd5c6b79d11e08a987512c1f8a0dd995a0b85f788592741a562cf44150b3328e24da6d2af851057d91b5ac3968a923e028d2fb673e4f344ea4e4bc2e412ba9b69cb1773b710d534c42d2e26f5b2f2b069f30ad88f95bbd2fb66ced02c716b4769a59dc5f549fe2ed6b2dc000d7b95278699adcbd717980d270647a1c35f340087b81bdc0b2cfeb60c1e1039ccdccf75f90c27a02674620dd3fbc7f04ba639b9b81711a8751338fbcfe631a3edb8ebec30b8020db90122df9f6652cd33a0e8cb366c2e1b49e09fbaf092d74b375a2b8d55439d1516d8f0baedf33054ded	10d6020e48c5ab3d5d57764b8c169011:45fefbc018b402d5c5fcbdcc9754cd0a33960842ac6355f95edf9a562b354ac6e042178652d8abbe600bc23057a004e9	2025-07-27 00:42:31.865	active	2025-07-26 01:05:37.983521	2025-07-26 00:42:31.866041	2025-07-26 01:05:37.983521	\N	\N	\N	\N	v2	1	1744566690	t	\N	{}	t
\.


--
-- TOC entry 3677 (class 0 OID 304270)
-- Dependencies: 228
-- Data for Name: stream_app_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_app_keys (id, app_id, key_name, stream_key, description, is_active, usage_count, last_used_at, created_at, updated_at) FROM stdin;
ed3efe4f-f61f-480c-8bb4-843466e51605	ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	YouTube	5b4w-rb4a-mrae-ddpq-ewus	Stream key for YouTube	t	6	2025-07-13 17:31:34.691726+00	2025-07-13 16:30:28.079562+00	2025-07-13 17:31:34.691726+00
834fde4f-12db-45d3-ace2-c428d31194c8	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	primary	live	Primary stream key	t	0	\N	2025-07-13 17:42:20.057337+00	2025-07-13 17:42:20.057337+00
8c6bdf90-2023-48a4-a16a-172a71c56e5d	d4832d1c-582c-42cd-b7d6-5ddcc00efffd	YouTube	5b4w-rb4a-mrae-ddpq-ewus	Stream key for YouTube	t	1	2025-07-13 17:43:34.614186+00	2025-07-13 17:43:12.817868+00	2025-07-13 17:43:34.614186+00
\.


--
-- TOC entry 3678 (class 0 OID 304280)
-- Dependencies: 229
-- Data for Name: stream_apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_apps (id, user_id, app_name, description, rtmp_app_path, default_stream_key, status, settings, created_at, updated_at) FROM stdin;
ae00aa90-d946-4ed2-ad3b-925e3f1c0c97	2	Social Media Public Stream		live	darshan	active	{}	2025-07-13 15:20:10.081986+00	2025-07-13 16:51:59.547488+00
d4832d1c-582c-42cd-b7d6-5ddcc00efffd	2	socialmedia		socialmedia	live	active	{}	2025-07-13 17:42:20.054991+00	2025-07-13 17:42:20.054991+00
\.


--
-- TOC entry 3679 (class 0 OID 304291)
-- Dependencies: 230
-- Data for Name: stream_republishing; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_republishing (id, stream_id, user_id, destination_name, destination_url, destination_port, destination_app, destination_stream, destination_key, enabled, priority, retry_attempts, status, last_error, last_connected_at, connection_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3680 (class 0 OID 304306)
-- Dependencies: 231
-- Data for Name: stream_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_sessions (id, stream_id, user_id, session_key, status, started_at, ended_at, duration_seconds, peak_viewers, viewer_count, bytes_sent, bytes_received, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3663 (class 0 OID 304074)
-- Dependencies: 214
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, status, created_at, updated_at) FROM stdin;
2	sri.ramanatha@uskfoundation.or.ke	$2a$12$0NJAOA7i2aN.QUzYevthT.xxcFhT6GSqfzNLUFB/8NzZdN93vLYH6	admin	approved	2025-07-25 23:35:21.261886	2025-07-25 23:35:21.261886
3	sri.ramanatha@kailasaafrica.org	$2a$12$CTo.UdntlIQ7pPCsByu55ehB4PH9NunW3P78OgRakTy7Rbeyxau7.	user	approved	2025-07-05 16:15:27.751028	2025-07-11 03:04:05.076738
4	sri.ramanatha@nithyanandauniversity.org	$2a$12$.TODVfgk8hEWTEfma1nTtOD8idMWhgJlwg2wzSOV7qVGCx4WpXeZO	user	approved	2025-07-05 20:03:44.317584	2025-07-05 23:07:28.234753
6	sri.shivathama@uskfoundation.or.ke	$2a$12$hW31meZ7BfJfwPPqXtOEDu8ge/TM8HYcaC5fJpdZS1Oq/lhi8mwtS	user	approved	2025-07-14 13:45:18.054306	2025-07-14 13:45:45.905546
5	newtest@test.com	$2a$12$VGsHDF.vfnDb7Odko5Q9IO92UAtNXin46TqMEQLY1mbH8fbHiaPM6	user	rejected	2025-07-06 15:47:32.749578	2025-07-26 00:05:10.31234
1	test@example.com	$2a$12$R7VVNYPCBuNP0gMbdmJeburTt6qk6fcp960Zbg6K0bFVldaYfuJJC	user	approved	2025-07-04 21:15:58.927269	2025-07-26 00:05:20.838636
\.


--
-- TOC entry 3682 (class 0 OID 304323)
-- Dependencies: 233
-- Data for Name: wordpress_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wordpress_categories (id, account_id, wp_category_id, name, slug, description, created_at, updated_at) FROM stdin;
1	1	4	Diplomatic Mission	diplomatic-mission	Diplomatic Mission	2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
2	1	22	Featured News	featured		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
3	1	9	Ghana	ghana		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
4	1	5	Humanitarian Services	humanitarian-services	Humanitarian Services	2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
5	1	15	Kenya	kenya		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
6	1	10	Liberia	liberia		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
7	1	21	Mauritius	mauritius		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
8	1	20	Paraguay	paraguay		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
9	1	8	Sierra Leone	sierra-leone		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
10	1	12	South Africa	south-africa		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
11	1	16	Tanzania	tanzania		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
12	1	11	Uganda	uganda		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
13	1	64	Uncategorized	uncategorized-en		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
14	1	1	Uncategorized	uncategorized		2025-07-24 21:39:50.922572+00	2025-07-24 21:39:50.922572+00
\.


--
-- TOC entry 3684 (class 0 OID 304332)
-- Dependencies: 235
-- Data for Name: wordpress_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wordpress_tags (id, account_id, wp_tag_id, name, slug, description, created_at, updated_at) FROM stdin;
1	1	28	africa	africa		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
2	1	27	food donations	food-donations		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
3	1	23	Kailasa	kailasa		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
4	1	29	NGO	ngo		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
5	1	24	Nithyananda	nithyananda		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
6	1	26	Service	service		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
7	1	25	servicwe	servicwe		2025-07-24 21:39:50.936321+00	2025-07-24 21:39:50.936321+00
8	2	28	africa	africa		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
9	2	27	food donations	food-donations		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
10	2	23	Kailasa	kailasa		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
11	2	29	NGO	ngo		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
12	2	24	Nithyananda	nithyananda		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
13	2	26	Service	service		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
14	2	25	servicwe	servicwe		2025-07-24 21:42:27.726159+00	2025-07-24 21:42:27.726159+00
\.


--
-- TOC entry 3700 (class 0 OID 0)
-- Dependencies: 219
-- Name: account_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_groups_id_seq', 2, false);


--
-- TOC entry 3701 (class 0 OID 0)
-- Dependencies: 221
-- Name: api_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_credentials_id_seq', 1, true);


--
-- TOC entry 3702 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_states_id_seq', 7, true);


--
-- TOC entry 3703 (class 0 OID 0)
-- Dependencies: 226
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 8, true);


--
-- TOC entry 3704 (class 0 OID 0)
-- Dependencies: 216
-- Name: reddit_subreddits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reddit_subreddits_id_seq', 10, true);


--
-- TOC entry 3705 (class 0 OID 0)
-- Dependencies: 227
-- Name: social_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_accounts_id_seq', 33, true);


--
-- TOC entry 3706 (class 0 OID 0)
-- Dependencies: 232
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- TOC entry 3707 (class 0 OID 0)
-- Dependencies: 234
-- Name: wordpress_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wordpress_categories_id_seq', 31, true);


--
-- TOC entry 3708 (class 0 OID 0)
-- Dependencies: 236
-- Name: wordpress_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wordpress_tags_id_seq', 14, true);


--
-- TOC entry 3439 (class 2606 OID 304350)
-- Name: account_groups account_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3441 (class 2606 OID 304352)
-- Name: account_groups account_groups_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_name_key UNIQUE (user_id, name);


--
-- TOC entry 3444 (class 2606 OID 304354)
-- Name: api_credentials api_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 3446 (class 2606 OID 304356)
-- Name: api_credentials api_credentials_platform_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_platform_key UNIQUE (platform);


--
-- TOC entry 3452 (class 2606 OID 304358)
-- Name: live_streams live_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3454 (class 2606 OID 304360)
-- Name: live_streams live_streams_stream_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_stream_key_key UNIQUE (stream_key);


--
-- TOC entry 3456 (class 2606 OID 304362)
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3458 (class 2606 OID 304364)
-- Name: oauth_states oauth_states_state_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_key_key UNIQUE (state_key);


--
-- TOC entry 3463 (class 2606 OID 304366)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3435 (class 2606 OID 304202)
-- Name: reddit_subreddits reddit_subreddits_account_id_subreddit_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reddit_subreddits
    ADD CONSTRAINT reddit_subreddits_account_id_subreddit_name_key UNIQUE (account_id, subreddit_name);


--
-- TOC entry 3437 (class 2606 OID 304200)
-- Name: reddit_subreddits reddit_subreddits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reddit_subreddits
    ADD CONSTRAINT reddit_subreddits_pkey PRIMARY KEY (id);


--
-- TOC entry 3433 (class 2606 OID 304101)
-- Name: social_accounts social_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3467 (class 2606 OID 304368)
-- Name: stream_app_keys stream_app_keys_app_id_key_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_app_id_key_name_key UNIQUE (app_id, key_name);


--
-- TOC entry 3469 (class 2606 OID 304370)
-- Name: stream_app_keys stream_app_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3473 (class 2606 OID 304372)
-- Name: stream_apps stream_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_pkey PRIMARY KEY (id);


--
-- TOC entry 3475 (class 2606 OID 304374)
-- Name: stream_apps stream_apps_rtmp_app_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_rtmp_app_path_key UNIQUE (rtmp_app_path);


--
-- TOC entry 3477 (class 2606 OID 304376)
-- Name: stream_apps stream_apps_user_id_app_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_user_id_app_name_key UNIQUE (user_id, app_name);


--
-- TOC entry 3482 (class 2606 OID 304378)
-- Name: stream_republishing stream_republishing_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_pkey PRIMARY KEY (id);


--
-- TOC entry 3487 (class 2606 OID 304380)
-- Name: stream_sessions stream_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3427 (class 2606 OID 304382)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3429 (class 2606 OID 304087)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3490 (class 2606 OID 304384)
-- Name: wordpress_categories wordpress_categories_account_id_wp_category_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories
    ADD CONSTRAINT wordpress_categories_account_id_wp_category_id_key UNIQUE (account_id, wp_category_id);


--
-- TOC entry 3492 (class 2606 OID 304386)
-- Name: wordpress_categories wordpress_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_categories
    ADD CONSTRAINT wordpress_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3495 (class 2606 OID 304388)
-- Name: wordpress_tags wordpress_tags_account_id_wp_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags
    ADD CONSTRAINT wordpress_tags_account_id_wp_tag_id_key UNIQUE (account_id, wp_tag_id);


--
-- TOC entry 3497 (class 2606 OID 304390)
-- Name: wordpress_tags wordpress_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wordpress_tags
    ADD CONSTRAINT wordpress_tags_pkey PRIMARY KEY (id);


--
-- TOC entry 3442 (class 1259 OID 304391)
-- Name: idx_account_groups_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_groups_user_id ON public.account_groups USING btree (user_id);


--
-- TOC entry 3447 (class 1259 OID 304392)
-- Name: idx_live_streams_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_app_id ON public.live_streams USING btree (app_id);


--
-- TOC entry 3448 (class 1259 OID 304393)
-- Name: idx_live_streams_app_key_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_app_key_id ON public.live_streams USING btree (app_key_id);


--
-- TOC entry 3449 (class 1259 OID 304394)
-- Name: idx_live_streams_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_status ON public.live_streams USING btree (status);


--
-- TOC entry 3450 (class 1259 OID 304395)
-- Name: idx_live_streams_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_live_streams_user_id ON public.live_streams USING btree (user_id);


--
-- TOC entry 3459 (class 1259 OID 304396)
-- Name: idx_posts_scheduled_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_scheduled_time ON public.posts USING btree (scheduled_time);


--
-- TOC entry 3460 (class 1259 OID 304397)
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- TOC entry 3461 (class 1259 OID 304398)
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- TOC entry 3430 (class 1259 OID 304399)
-- Name: idx_social_accounts_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_platform ON public.social_accounts USING btree (platform);


--
-- TOC entry 3431 (class 1259 OID 304400)
-- Name: idx_social_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_user_id ON public.social_accounts USING btree (user_id);


--
-- TOC entry 3464 (class 1259 OID 304401)
-- Name: idx_stream_app_keys_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_app_keys_active ON public.stream_app_keys USING btree (is_active);


--
-- TOC entry 3465 (class 1259 OID 304402)
-- Name: idx_stream_app_keys_app_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_app_keys_app_id ON public.stream_app_keys USING btree (app_id);


--
-- TOC entry 3470 (class 1259 OID 304403)
-- Name: idx_stream_apps_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_apps_status ON public.stream_apps USING btree (status);


--
-- TOC entry 3471 (class 1259 OID 304404)
-- Name: idx_stream_apps_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_apps_user_id ON public.stream_apps USING btree (user_id);


--
-- TOC entry 3478 (class 1259 OID 304405)
-- Name: idx_stream_republishing_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_status ON public.stream_republishing USING btree (status);


--
-- TOC entry 3479 (class 1259 OID 304406)
-- Name: idx_stream_republishing_stream_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_stream_id ON public.stream_republishing USING btree (stream_id);


--
-- TOC entry 3480 (class 1259 OID 304407)
-- Name: idx_stream_republishing_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_republishing_user_id ON public.stream_republishing USING btree (user_id);


--
-- TOC entry 3483 (class 1259 OID 304408)
-- Name: idx_stream_sessions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_status ON public.stream_sessions USING btree (status);


--
-- TOC entry 3484 (class 1259 OID 304409)
-- Name: idx_stream_sessions_stream_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_stream_id ON public.stream_sessions USING btree (stream_id);


--
-- TOC entry 3485 (class 1259 OID 304410)
-- Name: idx_stream_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_stream_sessions_user_id ON public.stream_sessions USING btree (user_id);


--
-- TOC entry 3425 (class 1259 OID 304411)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3488 (class 1259 OID 304412)
-- Name: idx_wordpress_categories_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wordpress_categories_account_id ON public.wordpress_categories USING btree (account_id);


--
-- TOC entry 3493 (class 1259 OID 304413)
-- Name: idx_wordpress_tags_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wordpress_tags_account_id ON public.wordpress_tags USING btree (account_id);


--
-- TOC entry 3513 (class 2620 OID 304414)
-- Name: account_groups update_account_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_account_groups_updated_at BEFORE UPDATE ON public.account_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3514 (class 2620 OID 304415)
-- Name: api_credentials update_api_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_credentials_updated_at BEFORE UPDATE ON public.api_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3515 (class 2620 OID 304416)
-- Name: live_streams update_live_streams_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_live_streams_updated_at BEFORE UPDATE ON public.live_streams FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3516 (class 2620 OID 304417)
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3512 (class 2620 OID 304418)
-- Name: social_accounts update_social_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_social_accounts_updated_at BEFORE UPDATE ON public.social_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3517 (class 2620 OID 304419)
-- Name: stream_app_keys update_stream_app_keys_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_app_keys_updated_at BEFORE UPDATE ON public.stream_app_keys FOR EACH ROW EXECUTE FUNCTION public.update_stream_apps_updated_at();


--
-- TOC entry 3518 (class 2620 OID 304420)
-- Name: stream_apps update_stream_apps_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_apps_updated_at BEFORE UPDATE ON public.stream_apps FOR EACH ROW EXECUTE FUNCTION public.update_stream_apps_updated_at();


--
-- TOC entry 3519 (class 2620 OID 304421)
-- Name: stream_republishing update_stream_republishing_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_republishing_updated_at BEFORE UPDATE ON public.stream_republishing FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3520 (class 2620 OID 304422)
-- Name: stream_sessions update_stream_sessions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_stream_sessions_updated_at BEFORE UPDATE ON public.stream_sessions FOR EACH ROW EXECUTE FUNCTION public.update_live_streams_updated_at();


--
-- TOC entry 3511 (class 2620 OID 304423)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3501 (class 2606 OID 304424)
-- Name: account_groups account_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3502 (class 2606 OID 304439)
-- Name: live_streams live_streams_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3503 (class 2606 OID 304444)
-- Name: oauth_states oauth_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3504 (class 2606 OID 304449)
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3500 (class 2606 OID 304203)
-- Name: reddit_subreddits reddit_subreddits_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reddit_subreddits
    ADD CONSTRAINT reddit_subreddits_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.social_accounts(id) ON DELETE CASCADE;


--
-- TOC entry 3498 (class 2606 OID 304454)
-- Name: social_accounts social_accounts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.account_groups(id) ON DELETE SET NULL;


--
-- TOC entry 3499 (class 2606 OID 304459)
-- Name: social_accounts social_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3505 (class 2606 OID 304464)
-- Name: stream_app_keys stream_app_keys_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.stream_apps(id) ON DELETE CASCADE;


--
-- TOC entry 3506 (class 2606 OID 304469)
-- Name: stream_apps stream_apps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3507 (class 2606 OID 304474)
-- Name: stream_republishing stream_republishing_stream_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_stream_id_fkey FOREIGN KEY (stream_id) REFERENCES public.live_streams(id) ON DELETE CASCADE;


--
-- TOC entry 3508 (class 2606 OID 304479)
-- Name: stream_republishing stream_republishing_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_republishing
    ADD CONSTRAINT stream_republishing_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3509 (class 2606 OID 304484)
-- Name: stream_sessions stream_sessions_stream_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_stream_id_fkey FOREIGN KEY (stream_id) REFERENCES public.live_streams(id) ON DELETE CASCADE;


--
-- TOC entry 3510 (class 2606 OID 304489)
-- Name: stream_sessions stream_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_sessions
    ADD CONSTRAINT stream_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-07-26 02:00:02 UTC

--
-- PostgreSQL database dump complete
--

