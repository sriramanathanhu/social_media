--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

-- Started on 2025-07-19 17:33:34 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_user_id_fkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_app_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_user_id_fkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_group_id_fkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_user_id_fkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_user_id_fkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_user_id_fkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_fkey;
DROP TRIGGER update_users_updated_at ON public.users;
DROP TRIGGER update_social_accounts_updated_at ON public.social_accounts;
DROP TRIGGER update_posts_updated_at ON public.posts;
DROP TRIGGER update_api_credentials_updated_at ON public.api_credentials;
DROP TRIGGER update_account_groups_updated_at ON public.account_groups;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_social_accounts_user_id;
DROP INDEX public.idx_social_accounts_platform;
DROP INDEX public.idx_posts_user_id;
DROP INDEX public.idx_posts_status;
DROP INDEX public.idx_posts_scheduled_time;
DROP INDEX public.idx_account_groups_user_id;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_rtmp_path_key;
ALTER TABLE ONLY public.stream_apps DROP CONSTRAINT stream_apps_pkey;
ALTER TABLE ONLY public.stream_app_keys DROP CONSTRAINT stream_app_keys_pkey;
ALTER TABLE ONLY public.social_accounts DROP CONSTRAINT social_accounts_pkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_state_key_key;
ALTER TABLE ONLY public.oauth_states DROP CONSTRAINT oauth_states_pkey;
ALTER TABLE ONLY public.live_streams DROP CONSTRAINT live_streams_pkey;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_platform_key;
ALTER TABLE ONLY public.api_credentials DROP CONSTRAINT api_credentials_pkey;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_user_id_name_key;
ALTER TABLE ONLY public.account_groups DROP CONSTRAINT account_groups_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.stream_apps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.stream_app_keys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.social_accounts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.oauth_states ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.live_streams ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.api_credentials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.account_groups ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.stream_apps_id_seq;
DROP TABLE public.stream_apps;
DROP SEQUENCE public.stream_app_keys_id_seq;
DROP TABLE public.stream_app_keys;
DROP SEQUENCE public.social_accounts_id_seq;
DROP TABLE public.social_accounts;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP SEQUENCE public.oauth_states_id_seq;
DROP TABLE public.oauth_states;
DROP SEQUENCE public.live_streams_id_seq;
DROP TABLE public.live_streams;
DROP SEQUENCE public.api_credentials_id_seq;
DROP TABLE public.api_credentials;
DROP SEQUENCE public.account_groups_id_seq;
DROP TABLE public.account_groups;
DROP FUNCTION public.update_updated_at_column();
--
-- TOC entry 232 (class 1255 OID 41992)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 41967)
-- Name: account_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    account_ids integer[] DEFAULT '{}'::integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 41966)
-- Name: account_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3563 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_groups_id_seq OWNED BY public.account_groups.id;


--
-- TOC entry 221 (class 1259 OID 41953)
-- Name: api_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_credentials (
    id integer NOT NULL,
    platform character varying(50) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret text NOT NULL,
    additional_config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 220 (class 1259 OID 41952)
-- Name: api_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.api_credentials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3564 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.api_credentials_id_seq OWNED BY public.api_credentials.id;


--
-- TOC entry 227 (class 1259 OID 42020)
-- Name: live_streams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.live_streams (
    id integer NOT NULL,
    user_id integer NOT NULL,
    stream_title character varying(255) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'inactive'::character varying,
    rtmp_url character varying(255),
    stream_key character varying(255),
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    viewer_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 226 (class 1259 OID 42019)
-- Name: live_streams_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.live_streams_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3565 (class 0 OID 0)
-- Dependencies: 226
-- Name: live_streams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.live_streams_id_seq OWNED BY public.live_streams.id;


--
-- TOC entry 225 (class 1259 OID 41997)
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_states (
    id integer NOT NULL,
    state_key character varying(255) NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    instance_url character varying(255),
    client_id character varying(255),
    client_secret character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '01:00:00'::interval),
    extra_data text
);


--
-- TOC entry 224 (class 1259 OID 41996)
-- Name: oauth_states_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_states_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3566 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_states_id_seq OWNED BY public.oauth_states.id;


--
-- TOC entry 219 (class 1259 OID 41933)
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    media_urls text[] DEFAULT '{}'::text[],
    platforms text[] NOT NULL,
    scheduled_time timestamp with time zone,
    status character varying(50) DEFAULT 'draft'::character varying,
    post_results jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    target_accounts text[] DEFAULT '{}'::text[],
    published_at timestamp with time zone,
    scheduled_for timestamp with time zone,
    error_message text,
    post_type character varying(20) DEFAULT 'text'::character varying,
    is_scheduled boolean DEFAULT false,
    CONSTRAINT posts_post_type_check CHECK (((post_type)::text = ANY ((ARRAY['text'::character varying, 'image'::character varying, 'video'::character varying, 'reel'::character varying])::text[]))),
    CONSTRAINT posts_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'scheduled'::character varying, 'published'::character varying, 'failed'::character varying])::text[])))
);


--
-- TOC entry 218 (class 1259 OID 41932)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3567 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 217 (class 1259 OID 41915)
-- Name: social_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_accounts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    platform_user_id character varying(255),
    username character varying(255) NOT NULL,
    display_name character varying(255),
    avatar_url text,
    instance_url character varying(255),
    access_token text,
    refresh_token text,
    token_expires_at timestamp with time zone,
    platform_data jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20) DEFAULT 'active'::character varying,
    last_used timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    site_url character varying(255),
    site_title character varying(255),
    group_id integer
);


--
-- TOC entry 216 (class 1259 OID 41914)
-- Name: social_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.social_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3568 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.social_accounts_id_seq OWNED BY public.social_accounts.id;


--
-- TOC entry 231 (class 1259 OID 42057)
-- Name: stream_app_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_app_keys (
    id integer NOT NULL,
    app_id integer NOT NULL,
    platform character varying(50) NOT NULL,
    stream_key character varying(255) NOT NULL,
    server_url character varying(255),
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 42056)
-- Name: stream_app_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stream_app_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3569 (class 0 OID 0)
-- Dependencies: 230
-- Name: stream_app_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stream_app_keys_id_seq OWNED BY public.stream_app_keys.id;


--
-- TOC entry 229 (class 1259 OID 42038)
-- Name: stream_apps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stream_apps (
    id integer NOT NULL,
    user_id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    description text,
    rtmp_path character varying(255) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 228 (class 1259 OID 42037)
-- Name: stream_apps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stream_apps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3570 (class 0 OID 0)
-- Dependencies: 228
-- Name: stream_apps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stream_apps_id_seq OWNED BY public.stream_apps.id;


--
-- TOC entry 215 (class 1259 OID 41900)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- TOC entry 214 (class 1259 OID 41899)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3571 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3326 (class 2604 OID 41970)
-- Name: account_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups ALTER COLUMN id SET DEFAULT nextval('public.account_groups_id_seq'::regclass);


--
-- TOC entry 3322 (class 2604 OID 41956)
-- Name: api_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials ALTER COLUMN id SET DEFAULT nextval('public.api_credentials_id_seq'::regclass);


--
-- TOC entry 3333 (class 2604 OID 42023)
-- Name: live_streams id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams ALTER COLUMN id SET DEFAULT nextval('public.live_streams_id_seq'::regclass);


--
-- TOC entry 3330 (class 2604 OID 42000)
-- Name: oauth_states id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states ALTER COLUMN id SET DEFAULT nextval('public.oauth_states_id_seq'::regclass);


--
-- TOC entry 3313 (class 2604 OID 41936)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3306 (class 2604 OID 41918)
-- Name: social_accounts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts ALTER COLUMN id SET DEFAULT nextval('public.social_accounts_id_seq'::regclass);


--
-- TOC entry 3342 (class 2604 OID 42060)
-- Name: stream_app_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys ALTER COLUMN id SET DEFAULT nextval('public.stream_app_keys_id_seq'::regclass);


--
-- TOC entry 3338 (class 2604 OID 42041)
-- Name: stream_apps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps ALTER COLUMN id SET DEFAULT nextval('public.stream_apps_id_seq'::regclass);


--
-- TOC entry 3301 (class 2604 OID 41903)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3549 (class 0 OID 41967)
-- Dependencies: 223
-- Data for Name: account_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_groups (id, user_id, name, description, account_ids, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3547 (class 0 OID 41953)
-- Dependencies: 221
-- Data for Name: api_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_credentials (id, platform, client_id, client_secret, additional_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3553 (class 0 OID 42020)
-- Dependencies: 227
-- Data for Name: live_streams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.live_streams (id, user_id, stream_title, description, status, rtmp_url, stream_key, start_time, end_time, viewer_count, created_at, updated_at) FROM stdin;
1	1	Test Live Stream	Sample live stream for testing	inactive	rtmp://37.27.201.26:1935/live	testkey123	\N	\N	0	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
2	1	Demo Stream	Demo streaming session	inactive	rtmp://37.27.201.26:1935/backup	demokey456	\N	\N	0	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
\.


--
-- TOC entry 3551 (class 0 OID 41997)
-- Dependencies: 225
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_states (id, state_key, user_id, platform, instance_url, client_id, client_secret, created_at, expires_at, extra_data) FROM stdin;
\.


--
-- TOC entry 3545 (class 0 OID 41933)
-- Dependencies: 219
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, user_id, content, media_urls, platforms, scheduled_time, status, post_results, created_at, updated_at, target_accounts, published_at, scheduled_for, error_message, post_type, is_scheduled) FROM stdin;
\.


--
-- TOC entry 3543 (class 0 OID 41915)
-- Dependencies: 217
-- Data for Name: social_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_accounts (id, user_id, platform, platform_user_id, username, display_name, avatar_url, instance_url, access_token, refresh_token, token_expires_at, platform_data, is_active, created_at, updated_at, status, last_used, site_url, site_title, group_id) FROM stdin;
1	1	wordpress	\N	admin	Site Administrator	\N	\N	encrypted_password_here	\N	\N	{}	t	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00	active	2025-07-19 16:28:02.139289+00	https://unitedancientnations.org	United Ancient Nations	\N
\.


--
-- TOC entry 3557 (class 0 OID 42057)
-- Dependencies: 231
-- Data for Name: stream_app_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_app_keys (id, app_id, platform, stream_key, server_url, status, created_at, updated_at) FROM stdin;
1	1	youtube	yt-key-12345	rtmp://a.rtmp.youtube.com/live2	active	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
2	1	facebook	fb-key-67890	rtmps://live-api-s.facebook.com:443/rtmp	active	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
3	2	twitch	twitch-key-abcde	rtmp://live.twitch.tv/live	active	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
\.


--
-- TOC entry 3555 (class 0 OID 42038)
-- Dependencies: 229
-- Data for Name: stream_apps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stream_apps (id, user_id, app_name, description, rtmp_path, status, created_at, updated_at) FROM stdin;
1	1	Main Stream App	Primary streaming application	live	active	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
2	1	Secondary Stream	Backup streaming application	backup	active	2025-07-19 16:28:02.139289+00	2025-07-19 16:28:02.139289+00
\.


--
-- TOC entry 3541 (class 0 OID 41900)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, status, created_at, updated_at) FROM stdin;
1	admin@restored.com	$2a$12$WIMn8a9tS9xgGjQmu0Fgp.4U7UxZR4GkyZjWkFuPS.r43.z2zZ1J2	admin	approved	2025-07-19 16:26:00.462769+00	2025-07-19 16:26:00.462769+00
2	test@example.com	$2a$12$nr3oxtNctHVv5aVmR2vA1.4PZhmh5X1mTzppbXZdbP1QrLFT0/1cS	admin	approved	2025-07-19 16:26:00.462769+00	2025-07-19 16:27:36.678703+00
\.


--
-- TOC entry 3572 (class 0 OID 0)
-- Dependencies: 222
-- Name: account_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_groups_id_seq', 1, false);


--
-- TOC entry 3573 (class 0 OID 0)
-- Dependencies: 220
-- Name: api_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.api_credentials_id_seq', 1, false);


--
-- TOC entry 3574 (class 0 OID 0)
-- Dependencies: 226
-- Name: live_streams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.live_streams_id_seq', 3, false);


--
-- TOC entry 3575 (class 0 OID 0)
-- Dependencies: 224
-- Name: oauth_states_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_states_id_seq', 1, false);


--
-- TOC entry 3576 (class 0 OID 0)
-- Dependencies: 218
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- TOC entry 3577 (class 0 OID 0)
-- Dependencies: 216
-- Name: social_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.social_accounts_id_seq', 2, false);


--
-- TOC entry 3578 (class 0 OID 0)
-- Dependencies: 230
-- Name: stream_app_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stream_app_keys_id_seq', 4, false);


--
-- TOC entry 3579 (class 0 OID 0)
-- Dependencies: 228
-- Name: stream_apps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stream_apps_id_seq', 3, false);


--
-- TOC entry 3580 (class 0 OID 0)
-- Dependencies: 214
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- TOC entry 3369 (class 2606 OID 41977)
-- Name: account_groups account_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3371 (class 2606 OID 41979)
-- Name: account_groups account_groups_user_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_name_key UNIQUE (user_id, name);


--
-- TOC entry 3365 (class 2606 OID 41963)
-- Name: api_credentials api_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 3367 (class 2606 OID 41965)
-- Name: api_credentials api_credentials_platform_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_credentials
    ADD CONSTRAINT api_credentials_platform_key UNIQUE (platform);


--
-- TOC entry 3378 (class 2606 OID 42031)
-- Name: live_streams live_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_pkey PRIMARY KEY (id);


--
-- TOC entry 3374 (class 2606 OID 42006)
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3376 (class 2606 OID 42008)
-- Name: oauth_states oauth_states_state_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_key_key UNIQUE (state_key);


--
-- TOC entry 3363 (class 2606 OID 41946)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3358 (class 2606 OID 41926)
-- Name: social_accounts social_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 3384 (class 2606 OID 42067)
-- Name: stream_app_keys stream_app_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3380 (class 2606 OID 42048)
-- Name: stream_apps stream_apps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_pkey PRIMARY KEY (id);


--
-- TOC entry 3382 (class 2606 OID 42050)
-- Name: stream_apps stream_apps_rtmp_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_rtmp_path_key UNIQUE (rtmp_path);


--
-- TOC entry 3352 (class 2606 OID 41913)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3354 (class 2606 OID 41911)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3372 (class 1259 OID 41991)
-- Name: idx_account_groups_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_account_groups_user_id ON public.account_groups USING btree (user_id);


--
-- TOC entry 3359 (class 1259 OID 41990)
-- Name: idx_posts_scheduled_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_scheduled_time ON public.posts USING btree (scheduled_time);


--
-- TOC entry 3360 (class 1259 OID 41989)
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- TOC entry 3361 (class 1259 OID 41988)
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- TOC entry 3355 (class 1259 OID 41987)
-- Name: idx_social_accounts_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_platform ON public.social_accounts USING btree (platform);


--
-- TOC entry 3356 (class 1259 OID 41986)
-- Name: idx_social_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_accounts_user_id ON public.social_accounts USING btree (user_id);


--
-- TOC entry 3350 (class 1259 OID 41985)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3397 (class 2620 OID 42015)
-- Name: account_groups update_account_groups_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_account_groups_updated_at BEFORE UPDATE ON public.account_groups FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3396 (class 2620 OID 42014)
-- Name: api_credentials update_api_credentials_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_credentials_updated_at BEFORE UPDATE ON public.api_credentials FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3395 (class 2620 OID 41995)
-- Name: posts update_posts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3394 (class 2620 OID 41994)
-- Name: social_accounts update_social_accounts_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_social_accounts_updated_at BEFORE UPDATE ON public.social_accounts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3393 (class 2620 OID 41993)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3388 (class 2606 OID 41980)
-- Name: account_groups account_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_groups
    ADD CONSTRAINT account_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3390 (class 2606 OID 42032)
-- Name: live_streams live_streams_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.live_streams
    ADD CONSTRAINT live_streams_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3389 (class 2606 OID 42009)
-- Name: oauth_states oauth_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3387 (class 2606 OID 41947)
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3385 (class 2606 OID 42074)
-- Name: social_accounts social_accounts_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.account_groups(id) ON DELETE SET NULL;


--
-- TOC entry 3386 (class 2606 OID 41927)
-- Name: social_accounts social_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3392 (class 2606 OID 42068)
-- Name: stream_app_keys stream_app_keys_app_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_app_keys
    ADD CONSTRAINT stream_app_keys_app_id_fkey FOREIGN KEY (app_id) REFERENCES public.stream_apps(id) ON DELETE CASCADE;


--
-- TOC entry 3391 (class 2606 OID 42051)
-- Name: stream_apps stream_apps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stream_apps
    ADD CONSTRAINT stream_apps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-07-19 17:33:35 UTC

--
-- PostgreSQL database dump complete
--

